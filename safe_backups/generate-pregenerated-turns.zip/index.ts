/*
  # Generate Pre-generated Turns Function

  1. Purpose
    - Generates 3 turns of dialogue (A → B → A) ahead of time
    - Stores pre-generated options in pregenerated_turns table
    - Uses single AI call to generate all 3 turns efficiently

  2. Security
    - Uses environment variables for API keys
    - Validates request format
    - Handles CORS properly

  3. Status
    - Phase 2: Full implementation with AI generation
*/

import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from 'jsr:@supabase/supabase-js@2';

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey"
};

function emojiOnlyLine(line: string): boolean {
  const trimmed = String(line || "").trim();
  if (!trimmed) return false;
  return /^[\p{Emoji_Presentation}\p{Extended_Pictographic}\uFE0F\s]+$/u.test(trimmed);
}

const OPENER_ACT_SKIP = new Set([
  "want", "think", "know", "feel", "felt", "need", "hope", "guess", "have", "been",
  "being", "just", "really", "still", "also", "would", "could", "should", "sorry",
  "glad", "sure", "yeah", "here", "there", "like", "love", "hate", "wish",
  "the", "and", "but", "that", "this", "with", "from", "your", "you", "was", "were",
  "what", "when", "where", "how", "why", "not", "for", "are", "did", "about",
  "into", "over", "them", "they", "her", "his", "she", "him", "our", "get", "got",
  "see", "saw", "hear", "heard", "make", "made", "very", "only"
]);

function escapeRegExp(value: string): string {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function sameActWords(acts: Set<string>): Set<string> {
  const words = new Set(acts);
  if ([...acts].some((word) => word.startsWith("congratul"))) {
    words.add("celebrate");
    words.add("celebrating");
    words.add("celebration");
    words.add("congrats");
    words.add("congratulations");
  }
  return words;
}

// The word is said as "I ...", and not only as "you ...".
function speakerClaimsWord(line: string, word: string): boolean {
  const escaped = escapeRegExp(word);
  const aboutYou = new RegExp(`\\byou(?:\\s+(?!i\\b|i'm\\b)\\w+){0,3}\\s+${escaped}\\b`, "i");
  const aboutMe = new RegExp(`\\b(?:i|i'm|i am|i was|i wasn't)(?:\\s+\\w+){0,8}\\s+${escaped}\\b`, "i");
  if (!aboutMe.test(line)) return false;
  if (!aboutYou.test(line)) return true;
  return aboutMe.test(line.replace(aboutYou, " "));
}

// The other person is quoting what was said, but the line still speaks as the opener or as nobody.
function otherPersonDodgesWhatWasSaid(line: string, story: string): boolean {
  if (/\bi want to understand your side of this\b/i.test(line)) return true;
  if (/\bhelp me see what you heard from me\b/i.test(line)) return true;
  if (/\btell me what landed wrong for you\b/i.test(line)) return true;
  if (/jealous/i.test(story) && /\bthey\s+(were|are|seemed|sounded)\s+jealous\b/i.test(line)) return true;
  const otherPersonJudged = /\b(she|he)\s+(said i|told me i|called me|interpreted|thought i)\b/i.test(story);
  const ownsIt = /\b(i heard|i said|i felt|i thought|i meant|made me|to me|i picked|i was answering)\b/i.test(line);
  if (!otherPersonJudged || ownsIt) return false;
  if (/\byou(?:'re| are)?\s+confused\b/i.test(line)) return true;
  if (/\byou took it the wrong way\b/i.test(line)) return true;
  if (/\byou (?:misread|misunderstood|interpreted)\b/i.test(line)) return true;
  return false;
}

// True only when a line says the opener's own act or feeling. A fair reply is left as it is.
function otherPersonSpeaksAsOpener(lines: string[], openerStory: string): boolean {
  const story = String(openerStory || "");
  if (!story.trim()) return false;
  const acts = new Set<string>();
  const takeActs = (re: RegExp) => {
    const pattern = new RegExp(re.source, re.flags);
    let match: RegExpExecArray | null;
    while ((match = pattern.exec(story))) {
      const word = match[1].toLowerCase();
      if (word.length >= 4 && !OPENER_ACT_SKIP.has(word)) acts.add(word);
    }
  };
  takeActs(/\bi(?:'m| am| was| wasn't| were)?\s+(?:just\s+|really\s+|only\s+|not\s+)?([a-z']{4,})/gi);
  takeActs(/\b(?:called me|said i am|said i was|told me i am|told me i was)\s+([a-z']{4,})/gi);
  takeActs(/\buser a\s+(?:was\s+|is\s+|has\s+|had\s+)?([a-z']{4,})/gi);
  const claimed = sameActWords(acts);
  const nouns = new Set<string>();
  const nounSkip = new Set(["her", "his", "their", "your", "the", "new", "our", "this", "that", "very"]);
  const nounRe = /\b(?:about|on|over|regarding)\s+((?:[a-z]+\s+){0,3}[a-z]+)/gi;
  let nounMatch: RegExpExecArray | null;
  while ((nounMatch = nounRe.exec(story))) {
    for (const word of nounMatch[1].toLowerCase().split(/\s+/)) {
      if (word.length >= 3 && !nounSkip.has(word) && !OPENER_ACT_SKIP.has(word)) nouns.add(word);
    }
  }
  const openerUnsure = /\bi(?:'m| am) not sure\b/i.test(story);
  if (claimed.size === 0 && nouns.size === 0 && !openerUnsure) return false;
  const actList = [...claimed].map(escapeRegExp).join("|");
  const nounList = [...nouns].map(escapeRegExp).join("|");
  for (const raw of lines) {
    const line = String(raw || "").trim();
    if (!line || emojiOnlyLine(line)) continue;
    if (otherPersonDodgesWhatWasSaid(line, story)) return true;
    for (const word of claimed) {
      if (speakerClaimsWord(line, word)) return true;
    }
    if (openerUnsure && /\bi(?:'m| am) not sure\b/i.test(line) && (claimed.size > 0 || nouns.size > 0)) {
      const sharesStory = [...claimed, ...nouns].some((word) => new RegExp(`\\b${escapeRegExp(word)}\\b`, "i").test(line));
      if (sharesStory) return true;
    }
    if (actList && new RegExp(`\\bi(?:'m| am| was| wasn't)?\\s+(?:just\\s+|really\\s+|only\\s+|not\\s+)?(?:${actList})\\b`, "i").test(line)) {
      return true;
    }
    const claimsTheAct = /\b(i said|i told|when i said|i came across|i was trying|i wasn't trying|i was just trying|i didn't mean)\b/i.test(line);
    if (!claimsTheAct) continue;
    if (nounList && new RegExp(`\\b(?:${nounList})\\b`, "i").test(line)) return true;
  }
  return false;
}

// The opener's own three lines never enter this function.
function listenerAnswer(story: string, index: number): string {
  const actMatch = String(story || "").match(/\bi\s+(congratulated|apologized|asked|told|called|texted|messaged|brought|mentioned)\b/i);
  const labelMatch = String(story || "").match(/\b(?:said|called|told)\s+i\s+(?:am|was)\s+([a-z]+)/i);
  const act = actMatch ? actMatch[1].toLowerCase() : "";
  const label = labelMatch ? labelMatch[1].toLowerCase() : "";
  if (index % 2 === 1 && act && label) return `I heard you ${act} me, and I said you seemed ${label}.`;
  if (act && label) return `When you ${act} me, I said you seemed ${label}.`;
  if (act) return `When you ${act} me, I was answering what I heard.`;
  if (label) return `I said you seemed ${label} because of what I heard from you.`;
  return "I was answering what I heard you say.";
}

function keepOtherPersonsVoice(lines: string[], story: string): string[] {
  return lines.map((line, index) => {
    if (emojiOnlyLine(line)) return line;
    if (otherPersonSpeaksAsOpener([line], story)) return listenerAnswer(story, index);
    return line;
  });
}

async function askForOtherPersonsLines(
  apiKey: string,
  lines: string[],
  story: string,
  heard: string,
  hint: string,
  again: boolean
): Promise<string[] | null> {
  try {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01"
      },
      body: JSON.stringify({
        model: "claude-haiku-4-5-20251001",
        max_tokens: 500,
        temperature: again ? 0.2 : 0.4,
        system: "You fix who is speaking. Return JSON only.",
        messages: [{
          role: "user",
          content: `The person who opened this issue said: "${story}"
The latest line to answer is: "${heard}"
${hint ? `A private feeling already in play: "${hint}". Keep that feeling if a line already has it.` : ""}
These ${lines.length} replies belong to the OTHER person, the one who heard the opener.
${again ? "The last try still spoke as the opener. Do not copy those lines." : ""}
This is about what was said. Answer as the person who heard it, in this shape: "When you <their action>, I <what I felt or what I said back>."
Do not say "they" for either person. Do not say the opener is confused. Do not say the opener took it the wrong way.
Do not use "I want to understand your side of this."
Keep a reply unchanged only when it is already the other person's own words.
A reply that says the opener's action or feeling as "I" is not the other person's words. Rewrite that reply.
If a reply is only an emoji, copy it unchanged.
Do not apologize as the opener. Do not say the opener's action as "I". Do not say the opener's feeling as "I", including "I'm not sure" and "I wasn't" about what they were called.
Return exactly ${lines.length} replies.
Current replies:
${lines.map((line) => `- ${line}`).join("\n")}
JSON: {"options":["reply"]}`
        }]
      })
    });
    if (!response.ok) return null;
    const data = await response.json();
    const text = data?.content?.[0]?.text || "";
    let options: string[] = [];
    try {
      options = JSON.parse(text).options || [];
    } catch {
      const match = text.match(/\{[\s\S]*"options"[\s\S]*\}/);
      if (match) options = JSON.parse(match[0]).options || [];
    }
    const rewritten = options.map((line) => String(line || "").trim()).filter((line) => line.length > 0);
    if (rewritten.length !== lines.length) return null;
    return rewritten.map((line, index) => (emojiOnlyLine(lines[index]) ? lines[index] : line));
  } catch (err) {
    console.warn("⚠️ Could not check the other person's voice", err);
    return null;
  }
}

// Ask for the other person's lines again. Do not flip I and you here.
async function rewriteOtherPersonsLines(
  apiKey: string,
  lines: string[],
  openerStory: string,
  latestLine: string,
  privateHint: string
): Promise<string[] | null> {
  const clean = lines.map((line) => String(line ?? "").trim());
  if (!apiKey || clean.length === 0 || clean.every((line) => !line)) return null;
  const story = String(openerStory || "").replace(/\s+/g, " ").slice(0, 700);
  if (!otherPersonSpeaksAsOpener(clean, story)) return null;
  const heard = String(latestLine || "").replace(/\s+/g, " ").slice(0, 300);
  const hint = String(privateHint || "").replace(/\s+/g, " ").slice(0, 300);
  let rewritten = await askForOtherPersonsLines(apiKey, clean, story, heard, hint, false);
  const stillOpener = (set: string[] | null) =>
    !set || set.some((line, index) => !emojiOnlyLine(clean[index]) && otherPersonSpeaksAsOpener([line], story));
  if (stillOpener(rewritten)) {
    const second = await askForOtherPersonsLines(apiKey, rewritten || clean, story, heard, hint, true);
    if (second) rewritten = second;
  }
  const source = rewritten && rewritten.length === clean.length ? rewritten : clean;
  const fixed = keepOtherPersonsVoice(
    source.map((line, index) => (emojiOnlyLine(clean[index]) ? clean[index] : line)),
    story
  );
  console.log("ℹ️ Checked the other person's lines are in their voice");
  return fixed;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders
    });
  }

  try {
    console.log('🔧 generate-pregenerated-turns called');

    const requestBody = await req.json();
    const { chatId, hintFromB: hintFromBParam, latestMessageFromA, activeTurnNumber, batchStartTurn, closureState: closureStateParam, userASmileySent: userASmileySentParam, userBSmileySent: userBSmileySentParam } = requestBody;

    if (!chatId) {
      return new Response(JSON.stringify({
        error: 'chatId is required'
      }), {
        status: 400,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }

    // Initialize Supabase client with service role key
    const supabaseUrl = Deno.env.get('SUPABASE_URL') || '';
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || '';
    const CLAUDE_API_KEY = Deno.env.get('CLAUDE_API_KEY') || '';
    
    if (!supabaseUrl || !supabaseServiceKey) {
      return new Response(JSON.stringify({
        error: 'Supabase configuration missing'
      }), {
        status: 500,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }

    if (!CLAUDE_API_KEY) {
      return new Response(JSON.stringify({
        error: 'CLAUDE_API_KEY not configured'
      }), {
        status: 500,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }

    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Load chat row and context_data
    const { data: chatData, error: chatError } = await supabase
      .from("chats")
      .select("id, user_id, contact_id, context_data, closure_state, user_a_smiley_sent, user_b_smiley_sent")
      .eq("id", chatId)
      .maybeSingle(); // ✅ FIX: Use maybeSingle() instead of single() for safer error handling

    if (chatError || !chatData) {
      return new Response(JSON.stringify({
        error: 'Chat not found',
        details: chatError?.message
      }), {
        status: 404,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }

    // ✅ FIX 2: Check for pendingHint flag - if set, refuse to regenerate
    // This prevents premature regeneration when User B submits hint during User A's turn
    // BUT allow regeneration when latestMessageFromA is provided (User A has selected their turn)
    const contextData = chatData.context_data || {};
    const pendingHint = contextData.pendingHint === true;
    
    // ✅ CRITICAL: hint_from_b is persistent state - always fetch from param OR context_data
    // If hint exists in either place, it MUST be used (trimmed and validated)
    let hintFromB = '';
    if (hintFromBParam && hintFromBParam.trim().length > 0) {
      hintFromB = hintFromBParam.trim();
    } else if (contextData.hint_from_b && typeof contextData.hint_from_b === 'string' && contextData.hint_from_b.trim().length > 0) {
      hintFromB = contextData.hint_from_b.trim();
    }
    
    // ✅ CRITICAL: Log hint source for debugging continuity
    if (hintFromB) {
      console.log('✅ Hint continuity: Using hintFromB', {
        source: hintFromBParam ? 'request_body' : 'context_data',
        length: hintFromB.length,
        preview: hintFromB.substring(0, 50) + '...'
      });
    }
    
    // ✅ Extract closure state from request body or database (similar to hintFromB)
    const closureState = closureStateParam || chatData.closure_state || 'active';
    const userASmileySent = userASmileySentParam !== undefined ? userASmileySentParam : (chatData.user_a_smiley_sent || false);
    const userBSmileySent = userBSmileySentParam !== undefined ? userBSmileySentParam : (chatData.user_b_smiley_sent || false);
    
    console.log('✅ Closure state extracted:', {
      closureState,
      userASmileySent,
      userBSmileySent,
      source: closureStateParam ? 'request_body' : 'database'
    });

    console.log('🔵🔵🔵🔵🔵🔵🔵🔵🔵🔵🔵🔵🔵🔵🔵🔵🔵🔵🔵🔵🔵🔵🔵🔵🔵🔵🔵🔵🔵🔵');
    console.log('🚀 BACKEND: generate-pregenerated-turns called');
    console.log('🔵🔵🔵🔵🔵🔵🔵🔵🔵🔵🔵🔵🔵🔵🔵🔵🔵🔵🔵🔵🔵🔵🔵🔵🔵🔵🔵🔵🔵🔵');
    
    // ✅ STEP 4: Logging infrastructure - payload hint received (always logs)
    console.log('📥 PAYLOAD HINT RECEIVED: Edge function received', {
      functionName: 'generate-pregenerated-turns',
      chatId,
      hintFromBParam: hintFromBParam ? hintFromBParam.substring(0, 50) + "..." : null,
      hintFromBParamLength: hintFromBParam?.length || 0,
      hintFromContext: contextData.hint_from_b ? contextData.hint_from_b.substring(0, 50) + "..." : null,
      hintFromContextLength: contextData.hint_from_b?.length || 0,
      finalHintUsed: hintFromB ? hintFromB.substring(0, 50) + "..." : null,
      finalHintLength: hintFromB.length,
      hintSource: hintFromBParam ? 'request_body' : (contextData.hint_from_b ? 'context_data' : 'none'),
      timestamp: new Date().toISOString()
    });
    
    console.log('🔍 Backend hint check:', {
      chatId,
      hasHintFromBParam: !!hintFromBParam,
      hintFromBParamLength: hintFromBParam?.length || 0,
      hasHintFromContext: !!contextData.hint_from_b,
      hintFromContextLength: contextData.hint_from_b?.length || 0,
      hintFromBLength: hintFromB.length,
      pendingHint,
      hasLatestMessageFromA: !!latestMessageFromA,
      latestMessageFromALength: latestMessageFromA?.length || 0,
      hintSource: hintFromBParam ? 'request_body' : (contextData.hint_from_b ? 'context_data' : 'none'),
      willBlock: pendingHint && !latestMessageFromA
    });

    if (pendingHint && !latestMessageFromA) {
      console.log('DEFERRED_REGEN_BLOCKED_PENDING_HINT:', {
        chatId,
        pendingHint: true,
        hasLatestMessageFromA: false,
        reason: 'User A has not selected their active turn yet'
      });
      console.log('🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑');
      console.log('⏸️ BACKEND: pendingHint flag is set - regeneration is deferred until active turn is selected');
      console.log('📊 This regeneration call is being rejected to prevent premature regeneration');
      console.log('✅ Regeneration will happen automatically after the active turn is selected');
      console.log('🔍 Blocking details:', {
        pendingHint,
        hasLatestMessageFromA: !!latestMessageFromA,
        reason: 'User A has not selected their active turn yet'
      });
      console.log('🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑');
      
      return new Response(JSON.stringify({
        success: false,
        message: 'Regeneration deferred - pendingHint flag is set',
        details: 'Regeneration will happen after the active turn is selected',
        deferred: true
      }), {
        status: 200, // 200 because this is expected behavior, not an error
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }


    // Identify User A and User B
    const userAId = chatData.user_id;
    const userBId = chatData.contact_id;

    if (!userAId || !userBId) {
      return new Response(JSON.stringify({
        error: 'Chat missing user_id or contact_id'
      }), {
        status: 400,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }

    // ✅ RULE 1: Get last message to determine next recipient (no message count needed)
    // Load last message only to determine who should get the next turn
    const { data: lastMessageData, error: lastMessageError } = await supabase
      .from("messages")
      .select("sender_id")
      .eq("chat_id", chatId)
      .order("created_at", { ascending: false })
      .limit(1)
      .maybeSingle();

    if (lastMessageError && lastMessageError.code !== 'PGRST116') { // PGRST116 = no rows returned
      console.error('❌ Failed to load last message:', lastMessageError);
      return new Response(JSON.stringify({
        error: 'Failed to load conversation history',
        details: lastMessageError.message
      }), {
        status: 500,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }

    // Get last sender to determine next recipient
    let lastSenderId = lastMessageData ? String(lastMessageData.sender_id) : null;

    // Load last 4 conversation messages (reduced from 8 to minimize token usage)
    const { data: rawMessages, error: messagesError } = await supabase
  .from("messages")
  .select("id, sender_id, content, created_at")
  .eq("chat_id", chatId)
  .order("created_at", { ascending: false }) // newest first
  .limit(4);

// reorder chronologically for history
const messagesData = (rawMessages || []).sort(
  (a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime()
);


    if (messagesError) {
      console.error('❌ Failed to load messages:', messagesError);
      return new Response(JSON.stringify({
        error: 'Failed to load conversation history',
        details: messagesError.message
      }), {
        status: 500,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }

    // Format conversation history
    const conversationHistory = (messagesData || []).map((msg: { id: string; sender_id: string; content: string; created_at: string }) => ({
      id: msg.id,
      sender_id: msg.sender_id,
      content: msg.content,
      created_at: msg.created_at
    }));

    // ✅ CRITICAL FIX: If latestMessageFromA is provided, ensure it's in conversation history
    // This handles race conditions where the message isn't yet visible in the messages table query
    if (latestMessageFromA && typeof latestMessageFromA === 'string' && latestMessageFromA.trim().length > 0) {
      // Check if the last message in history is already this message (by content and sender)
      const lastMessageInHistory = conversationHistory.length > 0 ? conversationHistory[conversationHistory.length - 1] : null;
      const isLastMessageAlreadyThis = lastMessageInHistory && 
        String(lastMessageInHistory.sender_id) === String(userAId) &&
        lastMessageInHistory.content.trim() === latestMessageFromA.trim();
      
      if (!isLastMessageAlreadyThis) {
        // Add User A's selected message to conversation history
        // Use a synthetic ID and current timestamp
        conversationHistory.push({
          id: `synthetic-${Date.now()}`,
          sender_id: userAId,
          content: latestMessageFromA.trim(),
          created_at: new Date().toISOString()
        });
        console.log('✅ Injected latestMessageFromA into conversation history:', {
          messagePreview: latestMessageFromA.substring(0, 50) + '...',
          conversationHistoryLength: conversationHistory.length,
          wasAlreadyInHistory: false
        });
        
        // ✅ CRITICAL FIX: Update lastSenderId after injection
        // This ensures firstTurnRole is calculated correctly when latestMessageFromA is provided
        lastSenderId = String(userAId);
        console.log('✅ Updated lastSenderId to User A after latestMessageFromA injection');
      } else {
        console.log('ℹ️ latestMessageFromA already in conversation history (no injection needed)');
      }
    }

    // Filter messages by sender for logging/debugging only
    const messagesFromA = conversationHistory.filter(m => String(m.sender_id) === String(userAId));
    const messagesFromB = conversationHistory.filter(m => String(m.sender_id) === String(userBId));

    // ✅ NEW: Detect if both sides have shared their perspectives
    // Check if User A has explained their issue (has event + feeling)
    const hasUserAExplained = messagesFromA.some((msg) => {
      const content = String(msg.content || '').toLowerCase();
      const vaguePatterns = [
        /i (just )?wanted (some )?clarity/i,
        /i didn't want to assume/i,
        /it left me wondering/i,
        /i wanted to understand/i,
        /i (just )?wanted to (talk|discuss|share)/i,
        /something (is|was) bothering me/i,
        /there's something (i|we) need to (talk|discuss)/i,
        /i have something to (discuss|talk about)/i,
      ];
      if (vaguePatterns.some(pattern => pattern.test(content))) return false;
      const hasEvent = /\b(when|didn't|wasn't|did|was|because|after|before|since|while)\b/i.test(content) ||
                       /\b(ignored|replied|responded|said|did|left|canceled|forgot|missed)\b/i.test(content);
      const hasFeeling = /\b(felt|hurt|upset|confused|bothered|sad|angry|disappointed|worried|uncomfortable)\b/i.test(content);
      return hasEvent && hasFeeling;
    });

    // Check if User B has explained their perspective
    const hasUserBExplained = messagesFromB.some((msg) => {
      const content = String(msg.content || '').toLowerCase();
      return content.includes('i felt') || 
             content.includes('i was') || 
             content.includes('i thought') ||
             content.includes('from my side') ||
             content.includes('my perspective') ||
             content.includes('what happened was') ||
             content.includes('the reason') ||
             content.includes('because i') ||
             (content.includes('explain') && (content.includes('i') || content.includes('my')));
    });

    // ✅ CRITICAL: Both sides have shared their perspectives
    const bothSidesShared = hasUserAExplained && hasUserBExplained && conversationHistory.length >= 6;
    
    // ✅ ENHANCED: Also check for mutual understanding signals (gratitude, forgiveness, understanding, closure signals)
    const recentMessagesText = conversationHistory.slice(-6).map(m => String(m.content || '').toLowerCase()).join(' ');
    const hasMutualUnderstanding = bothSidesShared && (
      /thank|grateful|appreciate|glad|happy we talked/.test(recentMessagesText) ||
      /sorry|forgive|understand|my bad|apologize/.test(recentMessagesText) ||
      /makes sense|get it|see your point|clear now|i hear you/.test(recentMessagesText) ||
      // ✅ NEW: Add closure signal patterns
      /let'?s continue|let'?s move forward|let'?s move on|we'?re good|we'?re okay|everything'?s good|everything'?s okay/i.test(recentMessagesText) ||
      /i'?m (glad|happy|relieved) (we|that)/i.test(recentMessagesText) ||
      /i (appreciate|value|respect) (you|that|your)/i.test(recentMessagesText) ||
      /i'?m committed|i'?m here|i support|i understand/i.test(recentMessagesText) ||
      /(thanks|thank you) (for|that)/i.test(recentMessagesText)
    );

    // ✅ NEW: Also detect closure readiness from recent messages even if bothSidesShared is false
    // This catches cases where closure signals appear but detection missed them
    const hasClosureSignals = conversationHistory.length >= 4 && (
      /let'?s continue|let'?s move forward|let'?s move on|we'?re good|we'?re okay|everything'?s good|everything'?s okay/i.test(recentMessagesText) ||
      /i'?m (glad|happy|relieved) (we|that)/i.test(recentMessagesText) ||
      /i (appreciate|value|respect) (you|that|your)/i.test(recentMessagesText) ||
      /i'?m committed|i'?m here|i support|i understand/i.test(recentMessagesText) ||
      /(thanks|thank you) (for|that)/i.test(recentMessagesText) ||
      /🤝|👍|😊|❤️|🫂|🙂|😂|😘|😍/.test(recentMessagesText) // Emoji signals
    );

    // ✅ CRITICAL FALLBACK: Also check recent messages for smiley to detect pending state
    // This handles race conditions where closure_state hasn't been updated yet
    const recentSmileyFromA = messagesFromA.length > 0 && 
      messagesFromA.slice(-2).some((msg) => {
        const content = String(msg.content || '').trim();
        return /^[\p{Emoji_Presentation}\p{Emoji}\u200d\ufe0f\s]+$/u.test(content) && 
               !/[a-zA-Z0-9]/.test(content);
      });
    
    const recentSmileyFromB = messagesFromB.length > 0 && 
      messagesFromB.slice(-2).some((msg) => {
        const content = String(msg.content || '').trim();
        return /^[\p{Emoji_Presentation}\p{Emoji}\u200d\ufe0f\s]+$/u.test(content) && 
               !/[a-zA-Z0-9]/.test(content);
      });
    
    // ✅ FALLBACK: If closure_state is 'active' but we detect a recent smiley, treat as pending
    let effectiveClosureState = closureState;
    if ((closureState === 'active' || !closureState) && !closureState?.startsWith('pending_')) {
      if (recentSmileyFromA && !recentSmileyFromB && !userBSmileySent) {
        effectiveClosureState = 'pending_user_b_smiley';
        console.log('🔍 FALLBACK: Detected User A smiley in recent messages, treating as pending_user_b_smiley');
      } else if (recentSmileyFromB && !recentSmileyFromA && !userASmileySent) {
        effectiveClosureState = 'pending_user_a_smiley';
        console.log('🔍 FALLBACK: Detected User B smiley in recent messages, treating as pending_user_a_smiley');
      }
    }
    
    // ✅ CRITICAL: Also check if closure_state was passed incorrectly but smiley flags are set
    if (effectiveClosureState === 'active' && (userASmileySent || userBSmileySent)) {
      if (userASmileySent && !userBSmileySent) {
        effectiveClosureState = 'pending_user_b_smiley';
        console.log('🔍 FALLBACK: userASmileySent=true but closure_state=active, treating as pending_user_b_smiley');
      } else if (userBSmileySent && !userASmileySent) {
        effectiveClosureState = 'pending_user_a_smiley';
        console.log('🔍 FALLBACK: userBSmileySent=true but closure_state=active, treating as pending_user_a_smiley');
      }
    }
    
    // Use effective closure state for all checks
    const finalClosureState = effectiveClosureState || closureState;
    
    console.log('🔍 Closure detection:', {
      hasUserAExplained,
      hasUserBExplained,
      bothSidesShared,
      hasMutualUnderstanding,
      hasClosureSignals,
      messageCount: conversationHistory.length,
      closureStateFromDB: closureState,
      effectiveClosureState,
      finalClosureState,
      recentSmileyFromA,
      recentSmileyFromB,
      userASmileySent,
      userBSmileySent
    });

    // ✅ HYBRID CONTEXT WINDOW: Update conversation progress summary if stale (best-effort, non-blocking)
    let conversationProgressSummary = contextData?.conversation_progress_summary || '';
    const currentMessageCount = conversationHistory.length;
    const lastSummaryMessageCount = contextData?.conversation_progress_message_count || 0;
    const summaryIsStale = (currentMessageCount - lastSummaryMessageCount) >= 12 || !conversationProgressSummary;

    if (summaryIsStale && currentMessageCount > 0) {
      try {
        console.log(`🔄 Updating conversation progress summary (stale: ${currentMessageCount - lastSummaryMessageCount} messages since last update)`);
        
        // Load more messages for summary generation (up to last 15 for better context)
        const { data: summaryMessagesData, error: summaryMessagesError } = await supabase
          .from("messages")
          .select("id, sender_id, content, created_at")
          .eq("chat_id", chatId)
          .order("created_at", { ascending: false })
          .limit(15);
        
        const summaryMessages = summaryMessagesError ? conversationHistory : 
          (summaryMessagesData || []).sort(
            (a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime()
          );
        
        // Use recent messages for summary (last 10 for good context while keeping tokens low)
        const messagesToSummarize = summaryMessages.slice(-10);
        
        // Build prompt for summary generation - use neutral third-person language
        const summaryPrompt = `Summarize the conversation progress in 2-3 concise sentences using NEUTRAL THIRD-PERSON language. Focus on:
- What has been discussed or resolved
- Current emotional state or progress
- Key points or understanding reached

CRITICAL: Use third-person neutral language (e.g., "User A explained...", "User B acknowledged...", "They discussed..."). 
- Use "User A" and "User B" labels consistently
- Do NOT use first-person ("I", "me", "my") 
- Do NOT use names or @ tags
- This summary will be stored and used as background context for both users

Recent conversation messages:
${messagesToSummarize.map((msg: any, idx: number) => {
          const content = typeof msg === 'object' ? msg.content : String(msg);
          const sender = typeof msg === 'object' && String(msg.sender_id) === String(userAId) ? 'User A' : 'User B';
          return `${idx + 1}. ${sender}: "${content.substring(0, 150)}${content.length > 150 ? '...' : ''}"`;
        }).join('\n')}

Generate a brief 2-3 sentence summary in NEUTRAL THIRD-PERSON language (using "User A" and "User B" labels) describing the conversation progress:`;

        // Generate new summary using Haiku (cost-efficient)
        const CLAUDE_API_KEY = Deno.env.get("CLAUDE_API_KEY");
        if (CLAUDE_API_KEY) {
          const summaryResponse = await fetch("https://api.anthropic.com/v1/messages", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "x-api-key": CLAUDE_API_KEY,
              "anthropic-version": "2023-06-01"
            },
            body: JSON.stringify({
              model: "claude-haiku-4-5-20251001",
              max_tokens: 200,
              temperature: 0.3,
              messages: [{
                role: "user",
                content: summaryPrompt
              }]
            })
          });

          if (summaryResponse.ok) {
            const summaryData = await summaryResponse.json();
            const newSummary = summaryData.content[0].text.trim();
            
            if (newSummary && newSummary.length > 20) {
              // Update context_data with new summary
              const { error: updateError } = await supabase
                .from("chats")
                .update({
                  context_data: {
                    ...contextData,
                    conversation_progress_summary: newSummary,
                    conversation_progress_message_count: currentMessageCount,
                    conversation_progress_last_updated_at: new Date().toISOString()
                  }
                })
                .eq("id", chatId);
              
              if (!updateError) {
                conversationProgressSummary = newSummary;
                // Update contextData reference for use later
                contextData.conversation_progress_summary = newSummary;
                contextData.conversation_progress_message_count = currentMessageCount;
                console.log(`✅ Conversation progress summary updated (${newSummary.length} chars)`);
              } else {
                console.warn("⚠️ Failed to update conversation_progress_summary in DB, using in-memory version:", updateError);
              }
            }
          }
        }
      } catch (error) {
        // ✅ Best-effort: Continue with existing summary (or empty) if update fails
        console.warn("⚠️ Conversation progress summary update failed, using existing summary:", error);
      }
    } else {
      console.log(`✅ Using existing conversation progress summary (${conversationProgressSummary.length} chars, ${currentMessageCount - lastSummaryMessageCount} messages since update)`);
    }

    // Extract context_data fields (contextData and hintFromB already extracted above for pendingHint check)
    const summarySharedNeutral = contextData.summary_shared_neutral || contextData.summary || '';
    const thoughtsA = contextData.thoughts_a || contextData.thoughts || '';
    const thoughtsB = contextData.thoughts_b || '';
    // ✅ CRITICAL: Use hint from request body if provided (avoids race condition), otherwise fall back to context_data
    // Note: hintFromB already extracted above for pendingHint validation

    console.log('📋 Context loaded:', {
      chatId,
      userAId,
      userBId,
      messageCount: conversationHistory.length,
      hasSummary: !!summarySharedNeutral,
      hasThoughtsA: !!thoughtsA,
      hasThoughtsB: !!thoughtsB,
      hasHint: !!hintFromB,
      hintLength: hintFromB.length,
      hintPreview: hintFromB ? `${hintFromB.substring(0, 100)}...` : null,
      hintSource: hintFromBParam ? 'request_body' : 'context_data',
      conversationHistoryLength: conversationHistory.length,
      conversationHistoryPreview: conversationHistory.slice(-3).map(m => ({
        sender: String(m.sender_id) === String(userAId) ? 'User A' : 'User B',
        content: m.content.substring(0, 50) + "..."
      }))
    });

    // ✅ ALWAYS compute startingTurnNumber FIRST (from batchStartTurn or DB max)
    // This must be done before firstTurnRole calculation
    const { data: maxTurnRow, error: maxTurnErr } = await supabase
      .from('pregenerated_turns')
      .select('turn_number')
      .eq('chat_id', chatId)
      .order('turn_number', { ascending: false })
      .limit(1)
      .maybeSingle();

    let startingTurnNumber = 0;

    // ✅ If batchStartTurn provided (hint refresh), use it
    if (batchStartTurn !== undefined && batchStartTurn !== null) {
      startingTurnNumber = batchStartTurn;
      console.log(`🔄 Hint refresh: Starting from batch start ${startingTurnNumber}`);
    } else if (maxTurnRow && typeof maxTurnRow.turn_number === 'number') {
      startingTurnNumber = maxTurnRow.turn_number + 1;
    }

    console.log("🔥 FIXED: Computed startingTurnNumber from DB:", { startingTurnNumber });

    // ✅ ALWAYS compute firstTurnRole from batch position (structural, not conversational)
    // This guarantees stable role sequence for ALL batches, regardless of hint refresh or normal pregeneration
    // Batch 0-2 → A→B→A, Batch 3-5 → B→A→B, Batch 6-8 → A→B→A, etc.
    // Completely removes lastSenderId-based role logic for pregenerated turns
    let firstTurnRole: "A" | "B";
    const batchIndex = Math.floor(startingTurnNumber / 3);
    firstTurnRole = (batchIndex % 2 === 0) ? "A" : "B";
    console.log(`✅ Calculated firstTurnRole=${firstTurnRole} from batch position (batchIndex=${batchIndex}, startingTurnNumber=${startingTurnNumber})`);

    // ✅ RULE: When batchStartTurn is provided, still fetch existingTurns to prevent duplicates
    // Frontend deletes only unselected turns, so turns with selected_message may still exist
    // We must check for existing turns (by turn_number only) to avoid duplicate insertions
    if (batchStartTurn !== undefined && batchStartTurn !== null) {
      console.log(`🔄 FORCED REGENERATION: batchStartTurn=${batchStartTurn} provided - bypassing idempotency check but will still check for existing turns to prevent duplicates`);
      console.log(`🔄 Frontend has already deleted batch ${batchStartTurn}-${batchStartTurn + 2} (unselected turns only) - proceeding with forced regeneration`);
    } else {
      // ✅ IDEMPOTENCY CHECK: Verify the batch doesn't already exist (normal flow only)
      // Check if all 3 turns (startingTurnNumber, startingTurnNumber+1, startingTurnNumber+2) already exist
      // ✅ FIX: Check each turn with its specific recipient_id
      const firstTurnRecipientId = firstTurnRole === "A" ? userAId : userBId;
      const secondTurnRecipientId = firstTurnRole === "A" ? userBId : userAId;
      const thirdTurnRecipientId = firstTurnRole === "A" ? userAId : userBId;
      
      // Check each turn individually with its recipient_id
      const { data: turn1 } = await supabase
        .from('pregenerated_turns')
        .select('turn_number')
        .eq('chat_id', chatId)
        .eq('turn_number', startingTurnNumber)
        .eq('recipient_id', firstTurnRecipientId)
        .maybeSingle();
      
      const { data: turn2 } = await supabase
        .from('pregenerated_turns')
        .select('turn_number')
        .eq('chat_id', chatId)
        .eq('turn_number', startingTurnNumber + 1)
        .eq('recipient_id', secondTurnRecipientId)
        .maybeSingle();
      
      const { data: turn3 } = await supabase
        .from('pregenerated_turns')
        .select('turn_number')
        .eq('chat_id', chatId)
        .eq('turn_number', startingTurnNumber + 2)
        .eq('recipient_id', thirdTurnRecipientId)
        .maybeSingle();
      
      if (turn1 && turn2 && turn3) {
        console.log(`⏸️ Batch ${startingTurnNumber}-${startingTurnNumber + 2} already exists with correct recipient_ids - skipping generation`);
        return new Response(JSON.stringify({
          success: true,
          stored: 0,
          startingTurnNumber,
          turnNumbers: [startingTurnNumber, startingTurnNumber + 1, startingTurnNumber + 2],
          insertedTurnNumbers: [],
          message: 'Batch already exists'
        }), {
          status: 200,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }
    }

    console.log(`📊 Conversation state for pre-generation:`, {
      lastSenderId,
      firstTurnRole,
      messagesFromA,
      messagesFromB,
      startingTurnNumber,
      sequence: firstTurnRole === "A" ? "A→B→A" : "B→A→B"
    });

    // ✅ Hint handling: Delete unused turns to regenerate with hint context
    // ✅ GUARDRAIL 1: If activeTurnNumber is provided, ONLY regenerate that specific active turn
    // ✅ GUARDRAIL 2: Otherwise, delete entire batch [startingTurnNumber, startingTurnNumber+1, startingTurnNumber+2]
    // ❌ REMOVED: Turn-number adjustment logic (startingTurnNumber modification)
    // startingTurnNumber is now ALWAYS max(turn_number) + 1 from DB - never modified
    const hasHint = !!hintFromBParam || !!hintFromB;
    let hintRefreshMode = false; // Track if we're in hint refresh mode (single turn)
    
    if (hasHint && activeTurnNumber !== undefined && activeTurnNumber !== null) {
      // ✅ HINT REFRESH MODE: Only regenerate the active turn
      hintRefreshMode = true;
      console.log(`🔄 HINT REFRESH MODE: Regenerating ONLY active turn ${activeTurnNumber} with hint context`);
      
      // Find the recipient_id for this turn
      const { data: activeTurnData } = await supabase
        .from("pregenerated_turns")
        .select("recipient_id")
        .eq("chat_id", chatId)
        .eq("turn_number", activeTurnNumber)
        .maybeSingle();
      
      if (activeTurnData?.recipient_id) {
        // Delete only this specific active turn
        const { error: deleteError } = await supabase
          .from("pregenerated_turns")
          .delete()
          .eq("chat_id", chatId)
          .eq("turn_number", activeTurnNumber)
          .eq("recipient_id", activeTurnData.recipient_id)
          .is("selected_message", null);
        
        if (deleteError) {
          console.warn('⚠️ Failed to delete active turn for hint refresh (non-critical):', deleteError);
        } else {
          console.log(`✅ Deleted active turn ${activeTurnNumber} for hint refresh`);
        }
        
        // ✅ CRITICAL: Override startingTurnNumber to the active turn for single-turn generation
        startingTurnNumber = activeTurnNumber;
        console.log(`✅ Overriding startingTurnNumber to ${activeTurnNumber} for hint refresh`);
      } else {
        console.warn(`⚠️ Active turn ${activeTurnNumber} not found - falling back to batch mode`);
        hintRefreshMode = false;
      }
    } else if (hasHint) {
      // ✅ NORMAL BATCH MODE: Delete entire batch when hint is provided (for normal batch refill)
      const batchStart = startingTurnNumber;
      const batchEnd = startingTurnNumber + 2;
      console.log(`DELETE_HINT_BATCH_RANGE: start=${batchStart}, end=${batchEnd}, chatId=${chatId}`);
      console.log(`🔄 Hint provided - deleting unused turns from current batch [${batchStart}, ${batchStart + 1}, ${batchEnd}]`);
      
      const batchFirstRecipientId  = firstTurnRole === "A" ? userAId : userBId;
      const batchSecondRecipientId = firstTurnRole === "A" ? userBId : userAId;
      const batchThirdRecipientId  = firstTurnRole === "A" ? userAId : userBId;

      // ✅ FIX: Delete ONLY unused turns from current batch, scoped by recipient_id
      const { error: deleteError1 } = await supabase.from("pregenerated_turns")
        .delete()
        .eq("chat_id", chatId)
        .eq("turn_number", batchStart)
        .eq("recipient_id", batchFirstRecipientId)
        .is("selected_message", null);

      const { error: deleteError2 } = await supabase.from("pregenerated_turns")
        .delete()
        .eq("chat_id", chatId)
        .eq("turn_number", batchStart + 1)
        .eq("recipient_id", batchSecondRecipientId)
        .is("selected_message", null);

      const { error: deleteError3 } = await supabase.from("pregenerated_turns")
        .delete()
        .eq("chat_id", chatId)
        .eq("turn_number", batchEnd)
        .eq("recipient_id", batchThirdRecipientId)
        .is("selected_message", null);

      if (deleteError1 || deleteError2 || deleteError3) {
        console.warn('⚠️ Failed to delete some unused turns (non-critical):', deleteError1 || deleteError2 || deleteError3);
      } else {
        console.log(`✅ Deleted unused turns from current batch [${batchStart}, ${batchStart + 1}, ${batchEnd}]`);
      }
    }

    // ❌ REMOVED: Active turn skipping logic that modified startingTurnNumber
    // startingTurnNumber is now ALWAYS max(turn_number) + 1 from DB - never modified
    // Idempotency checks below will handle existing turns correctly

    // ✅ FIX 3: Idempotency check - check for ALL turns (used and unused) from starting point
    // Include selected_message to identify turns that should be preserved
    // ✅ FIX: Add recipient_id scoping - check each turn with its specific recipient
    // ✅ GUARDRAIL: In hint refresh mode, only check the active turn (not the entire batch)
    const firstRecipientId = firstTurnRole === "A" ? userAId : userBId;
    const secondRecipientId = firstTurnRole === "A" ? userBId : userAId;
    const thirdRecipientId = firstTurnRole === "A" ? userAId : userBId;
    
    let existingTurns: any[] = [];
    let hasAllExpectedTurns = false;
    let expectedTurnNumbers: number[] = [];
    let existingTurnNumbers: number[] = [];
    
    if (hintRefreshMode) {
      // ✅ HINT REFRESH MODE: Only check the active turn
      const { data: existingActiveTurn } = await supabase
        .from('pregenerated_turns')
        .select('turn_number, recipient_id, used_at, selected_message')
        .eq('chat_id', chatId)
        .eq('turn_number', startingTurnNumber)
        .maybeSingle();
      
      if (existingActiveTurn) {
        existingTurns = [existingActiveTurn];
        existingTurnNumbers = [startingTurnNumber];
        hasAllExpectedTurns = true; // Turn exists, but we deleted it above, so we'll regenerate
      } else {
        existingTurns = [];
        existingTurnNumbers = [];
        hasAllExpectedTurns = false; // Turn doesn't exist, we'll generate it
      }
      
      expectedTurnNumbers = [startingTurnNumber]; // Only the active turn
      console.log(`✅ Hint refresh mode: Only checking active turn ${startingTurnNumber}`);
    } else if (batchStartTurn !== undefined && batchStartTurn !== null) {
      // ✅ FIX: When batchStartTurn is provided, check for existing turns by turn_number only (no recipient_id filter)
      // This prevents duplicate insertions when frontend preserved turns with selected_message
      const { data: existingTurn1 } = await supabase
        .from('pregenerated_turns')
        .select('turn_number, recipient_id, used_at, selected_message')
        .eq('chat_id', chatId)
        .eq('turn_number', startingTurnNumber)
        .maybeSingle();
      
      const { data: existingTurn2 } = await supabase
        .from('pregenerated_turns')
        .select('turn_number, recipient_id, used_at, selected_message')
        .eq('chat_id', chatId)
        .eq('turn_number', startingTurnNumber + 1)
        .maybeSingle();
      
      const { data: existingTurn3 } = await supabase
        .from('pregenerated_turns')
        .select('turn_number, recipient_id, used_at, selected_message')
        .eq('chat_id', chatId)
        .eq('turn_number', startingTurnNumber + 2)
        .maybeSingle();
      
      existingTurns = [existingTurn1, existingTurn2, existingTurn3].filter(t => t !== null);
      expectedTurnNumbers = [startingTurnNumber, startingTurnNumber + 1, startingTurnNumber + 2];
      existingTurnNumbers = existingTurns?.map((t: { turn_number: number }) => t.turn_number) || [];
      hasAllExpectedTurns = false; // Always allow regeneration when batchStartTurn is provided, but existingTurns will prevent duplicates
      console.log(`✅ Batch refresh mode: Checking for existing turns ${expectedTurnNumbers.join(', ')} to prevent duplicates (found: ${existingTurnNumbers.join(', ') || 'none'})`);
    } else {
      // ✅ NORMAL BATCH MODE: Check all 3 turns
      const { data: existingTurn1 } = await supabase
        .from('pregenerated_turns')
        .select('turn_number, recipient_id, used_at, selected_message')
        .eq('chat_id', chatId)
        .eq('turn_number', startingTurnNumber)
        .eq('recipient_id', firstRecipientId)
        .maybeSingle();
      
      const { data: existingTurn2 } = await supabase
        .from('pregenerated_turns')
        .select('turn_number, recipient_id, used_at, selected_message')
        .eq('chat_id', chatId)
        .eq('turn_number', startingTurnNumber + 1)
        .eq('recipient_id', secondRecipientId)
        .maybeSingle();
      
      const { data: existingTurn3 } = await supabase
        .from('pregenerated_turns')
        .select('turn_number, recipient_id, used_at, selected_message')
        .eq('chat_id', chatId)
        .eq('turn_number', startingTurnNumber + 2)
        .eq('recipient_id', thirdRecipientId)
        .maybeSingle();
      
      existingTurns = [existingTurn1, existingTurn2, existingTurn3].filter(t => t !== null);
      
      // ✅ FIX: Check for exact turn_numbers that would be generated (startingTurnNumber, startingTurnNumber+1, startingTurnNumber+2)
      expectedTurnNumbers = [startingTurnNumber, startingTurnNumber + 1, startingTurnNumber + 2];
      existingTurnNumbers = existingTurns?.map((t: { turn_number: number }) => t.turn_number) || [];
      hasAllExpectedTurns = expectedTurnNumbers.every(tn => existingTurnNumbers.includes(tn));
    }
    
    // ✅ CRITICAL: Check for gaps in the sequence (missing turn numbers like 1, 3, etc.)
    const missingTurns = expectedTurnNumbers.filter(tn => !existingTurnNumbers.includes(tn));
    const hasGaps = missingTurns.length > 0;
    
    // ✅ FIX 3: Check if any expected turns have selected_message (should be preserved)
    const turnsWithSelectedMessage = existingTurns?.filter((t: { selected_message: any }) => t.selected_message !== null) || [];
    const hasUsedTurns = turnsWithSelectedMessage.length > 0;
    
    // ✅ CRITICAL FIX: More robust idempotency check - if ALL 3 expected turns exist (even if some are used), skip regeneration
    // This prevents deletion of turns that are currently being viewed by users or have been used
    // EXCEPTION 1: If hasHint is true AND NOT in hint refresh mode, ALWAYS allow regeneration (even if all turns exist) to include hint context
    // EXCEPTION 2: In hint refresh mode, we already deleted the active turn, so always regenerate it
    // Note: hasHint is already defined in the hint handling section above
    if (hasAllExpectedTurns && existingTurns && existingTurns.length >= 3 && !hasHint && !hintRefreshMode) {
      console.log(`✅ Already have all 3 pregenerated turns for turn_numbers ${expectedTurnNumbers.join(', ')}, skipping generation to prevent deletion of displayed turns`);
      return new Response(JSON.stringify({
        success: true,
        stored: 0,
        message: 'Pregenerated turns already exist for this range',
        existingTurns: existingTurns.length,
        startingTurnNumber,
        existingTurnNumbers
      }), {
        status: 200,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }
    
    // ✅ REMOVED: Partial batch deletion logic - this conflicts with hint deletion above
    // Hint deletion already handles current batch deletion when hasHint is true
    // If no hint, idempotency check above prevents unnecessary regeneration
    // This logic was causing duplicate deletions and conflicts with hint handling


    

    // ✅ FIX: Update system prompt to generate correct sequence - STRENGTHENED to require exactly 3 turns
    const systemPrompt = `You are SORTED — an emotionally-intelligent assistant guiding two people (User A and User B) through a supportive, respectful conversation.

⚡ CRITICAL REQUIREMENT - YOU MUST GENERATE EXACTLY 3 TURNS:
Your job: using the inputs below, generate EXACTLY 3 conversational turns (${firstTurnRole === "A" ? "A → B → A" : "B → A → B"}).  
NOT 1 turn. NOT 2 turns. EXACTLY 3 TURNS.
Each turn contains EXACTLY 3 short message options—supportive, natural, human-like.

MANDATORY OUTPUT STRUCTURE:
- Turn 1: ${firstTurnRole === "A" ? "User A" : "User B"} with 3 options
- Turn 2: ${firstTurnRole === "A" ? "User B" : "User A"} with 3 options  
- Turn 3: ${firstTurnRole === "A" ? "User A" : "User B"} with 3 options

RULES:
- No names or leaks (replace names with 'you', 'I', 'they' correctly).
- Each message must be exactly 1 complete line: a statement, a question, or an exclamation. Finish the thought. Do not cut it off. One small piece only.
- Tone: calm, kind, emotionally aware.
- Never judge either person.
- No emojis unless user uses them.
- Maintain continuity across all 3 turns.
- REAL CONVERSATION: All 3 choices answer the line just received and make the SAME point. Only the wording changes: one straight answer, one short reaction, one small question. Use the words they just used. Do not say "I didn't mean to hurt you" or "I understand why you'd feel that way" unless they just said they were hurt. The original problem stays in the background. Do not start a new subject, and do not repeat what was already said. If that line was already answered, the next choices may bring back one small piece of that person's own feeling, still as a reply. The line is what that person feels inside about what was just said. All 3 say that same feeling. Do not say "I'd like to talk about what happened earlier" once the chat has already begun. What belongs to that person stays in their mouth. What belongs to the other person stays in theirs.
- The other person in this chat is "you". You are "I". The story may use their name, or "she", or "he". That is still the person you are texting. Do not say that name. Do not say she or he for them. Say only your own side. Do not put their story in your mouth.
- On a User B turn only: all 3 choices are one answer to the line just received. Same meaning. One straight, one shorter, one small question. Do not give three different subjects. The saved story is User A's side. User B does not claim those actions. If User A was the one who congratulated, User B does not say "I was being nice about your car" and does not apologize as that person. Do not say "I'd like to talk about what happened earlier."
${hintFromB ? `
- 🔐 User B's turns only: all 3 choices are one answer to the line just received. Same meaning. One straight answer, that same answer shorter, that same answer as a small question. Do not give three different subjects. If a hint exists, that shared point is the hint. "@Name said I am lucky" becomes "You said I was lucky." Never "I am lucky" and never "People said I'm lucky" when the hint is about the other person. If they do not remember that word, all 3 choices bring it back. Hear that line, then keep the leftover feeling in the same casual text. Shape: "I hear you, but I'm still upset you called me jealous." Not only thanks. Not a goodbye.
- Do not contradict the hint. Do not show the hint to User A. Do not put the hint into User A's choices.
` : `
- If hint_from_b is provided, respect it as User B's private perspective.
`}
- If closure is detected, include 1 smiley-only option as one of the 3.
- Choose appropriate emoji from: 🙂 😊 😌 ❤️ 💕 🤝 ✨ based on relationship and tone
- Do NOT generate branching beyond ${firstTurnRole === "A" ? "A→B→A" : "B→A→B"}.
- Do NOT generate more than 3 turns.
- Do NOT generate fewer than 3 turns.

⚡ OUTPUT FORMAT - YOU MUST RETURN EXACTLY THIS STRUCTURE:

{
  "turns": [
    { "role": "${firstTurnRole}", "options": ["...", "...", "..."], "finalClosureDetected": false },
    { "role": "${firstTurnRole === "A" ? "B" : "A"}", "options": ["...", "...", "..."], "finalClosureDetected": false },
    { "role": "${firstTurnRole}", "options": ["...", "...", "..."], "finalClosureDetected": false }
  ]
}

⚡ CRITICAL: The "role" field MUST match the turn position EXACTLY:
- Turn 1 (index 0): role MUST be "${firstTurnRole}" (${firstTurnRole === "A" ? "User A" : "User B"})
- Turn 2 (index 1): role MUST be "${firstTurnRole === "A" ? "B" : "A"}" (${firstTurnRole === "A" ? "User B" : "User A"})
- Turn 3 (index 2): role MUST be "${firstTurnRole}" (${firstTurnRole === "A" ? "User A" : "User B"})

⚠️ IF YOU GET THE ROLE WRONG, THE ENTIRE RESPONSE WILL BE REJECTED AND REGENERATED.
⚠️ Double-check each turn's role matches its position in the sequence before returning.
⚠️ The role field determines which user sees these options - getting it wrong swaps options between users.

REMEMBER: EXACTLY 3 TURNS. NOT 1. NOT 2. EXACTLY 3.`;

    // ✅ FIX: Update user prompt to generate correct sequence
    const isFirstTurn = conversationHistory.length === 0;
    
    const userPrompt = `Use this conversation context:

summary_shared_neutral: ${summarySharedNeutral || '(none provided)'}

thoughts_a: ${thoughtsA || '(none provided)'}

thoughts_b: ${thoughtsB || '(none provided)'}

    // ✅ STEP 4: Logging infrastructure - prompt hint injection (always logs)
    const hintInPrompt = !!hintFromB && hintFromB.trim().length > 0;
    const hintSectionIncluded = hintInPrompt;
    console.log('📝 PROMPT HINT INJECTION: AI prompt construction', {
      functionName: 'generate-pregenerated-turns',
      chatId,
      hintInPrompt,
      hintSectionIncluded,
      hintTextInPrompt: hintInPrompt ? hintFromB.substring(0, 100) + "..." : null,
      hintConditionResult: hintInPrompt,
      timestamp: new Date().toISOString()
    });

${hintFromB ? `
🔐 USER B'S PRIVATE PERSPECTIVE (PERSISTENT CORE CONTEXT FOR ALL TURNS):
"${hintFromB}"

⚠️ CRITICAL: This hint is PRIVATE to User B and MUST NEVER be shown to User A.

On every User B turn, all 3 choices carry this same point. Only the wording changes: one statement, one short reaction, one question.
User B is "I". The other person is "you". Do not say their name.
If the hint says the other person said something ("@Name said I am lucky", "she said I am lucky"), User B says "You said I was lucky."
Never "I am lucky" as a new claim. Never "People have said I'm lucky" when the hint is about the other person.
If the other person does not remember that word, all 3 choices bring the word back.
Do not contradict the hint. Do not show the hint to User A. Do not put it in User A's choices.
Answer the line just received. The hint is what User B answers with.
Hear that line, then keep going in the same text. Casual, like a real text. The leftover feeling stays in the line.
Shape: "I hear you, but I'm still upset you called me jealous."
All 3 say that same leftover feeling. Not only thanks. Not a goodbye.

The hint reveals:
- What User B is GENUINELY feeling about the situation (emotional truth)
- Critical context and background User A doesn't fully understand
- User B's valid perspective, needs, and legitimate concerns
- The specific people, events, and dynamics involved
- User B's reasons for their feelings and reactions
- Opportunities to help both sides understand each other fairly

🎯 CRITICAL: COMPARE HINT WITH NEUTRAL TOPIC SUMMARY:
Topic context (neutral, factual): "${summarySharedNeutral || '(none provided)'}"
User B's Hint (User B's perspective): "${hintFromB}"

USER B REPLIES:
- Answer the line just received. Use the words they just used.
- All 3 choices make the SAME hint point. One straight answer, one short reaction, one small question.
- "@Name said I am lucky" is spoken as "You said I was lucky." If they do not remember, bring that word back in all 3.
- Do not contradict the hint. Do not show it to User A. Do not put it in User A's choices.
- Hear the line just sent, then keep the leftover feeling in the same casual text. Shape: "I hear you, but I'm still upset you called me jealous." Not only thanks. Not a goodbye.
- Do not say "I didn't mean to hurt you" unless they just said they were hurt.
` : `
hint_from_b: (none provided)
`}

conversation_history: ${JSON.stringify(conversationHistory, null, 2)}

${isFirstTurn ? `
🌱 VERY FIRST TURN - NATURAL HUMAN OPENING WITH GREETING:

Generate the FIRST turn (${firstTurnRole === "A" ? "User A" : "User B"}) with 3 options that:
1. INCLUDE CASUAL CHECK-IN GREETINGS naturally:
   - "Hey, how are you? Can we talk about something?"
   - "Hi, how's it going? Got something I wanted to discuss"
   - "Hey there, how have you been? Need to chat about something"

2. THEN TRANSITION TO THE ISSUE from summary:
   - "...can we talk about what happened at the party?"
   - "...there's something I wanted to discuss"
   - "...got something on my mind"

3. VARY THE STYLE:
   - Some start with casual greeting + check-in
   - Some are more direct but still warm
   - Some are situation-aware (embarrassed, happy, after fight, etc.)

Examples for first turn:
- "Hey, how are you? Can we talk about what happened at the party?"
- "Hi, hope you're doing well. I've been wanting to bring something up"
- "Hey there, how's everything going? Got something on my mind I'd like to discuss"

Keep them natural, human-like, and include casual greetings when appropriate.

For the remaining 2 turns (${firstTurnRole === "A" ? "B → A" : "A → B"}), generate 3 options each.

EACH OPTION IS ONE COMPLETE LINE, ONE SMALL PIECE:
- Reply to what was just said, but add only one new piece: one feeling, one reason, or one specific question.
- The person named in the story is the person you are texting. Say "you", not their name, and not she or he. Say only your own side. The line is that person's own feeling about what was just said. All 3 say that same feeling. Do not start a new subject.
- Do not pack a greeting, an apology, and a fix into the same line.
- In each set of 3, the point stays the same. Only the wording changes:
  * One statement, ending in a period
  * One question, ending in a question mark
  * One exclamation or reaction, ending in an exclamation mark
- Finish every line. Do not stop halfway.
- On a User B turn, if a hint exists, that shared point is the hint, spoken as "You said I ...".

✅ CORRECT EXAMPLES:
- Previous: "I am upset about the office issue."
  Options:
  * "I've been upset about that too." (straight)
  * "I've been upset about it too." (shorter)
  * "Have you been as upset about it as I have?" (same feeling, small question)

- Previous: "I felt hurt when you didn't reply."
  Options:
  * "I didn't realize my silence hurt you that much." (straight)
  * "I didn't realize it hurt you." (shorter)
  * "Did my silence hurt you that much?" (same feeling, small question)

❌ WRONG EXAMPLES (avoid these):
- "I hear you. I didn't realize it bothered you, and I want to fix this together." (too many pieces, and more than one line) ❌
- A line that stops halfway or ends with "..." ❌
- Three options that are all statements ❌
- "How are you?" (ignores what they just said) ❌

Continue the conversation naturally
Are supportive and consistent with the conversation
If near closure, include 1 smiley-only option as one of the 3
Choose appropriate emoji from: 🙂 😊 😌 ❤️ 💕 🤝 ✨
Match to relationship type and conversation tone:
- Family: ❤️ 💕 😊 😌 (warm, supportive)
- Friends: 😊 😌 🤝 ✨ (happy, friendly, playful)
- Work: 🤝 🙂 ✨ (professional, respectful)
- Romantic: ❤️ 💕 😊 😌 (intimate, caring, affectionate)
` : `
Generate 3 consecutive turns: ${firstTurnRole === "A" ? "A → B → A" : "B → A → B"}.
Each turn must include 3 options.

EACH OPTION IS ONE COMPLETE LINE, ONE SMALL PIECE:
- Reply to the previous turn, but add only one new piece from that person's side: one feeling, one reason, or one specific question.
- The person named in the story is the person you are texting. Say "you", not their name, and not she or he. Say only your own side. The line is that person's own feeling about what was just said. All 3 say that same feeling. Do not start a new subject.
- Do not explain both sides, apologize, and resolve it in the same line. The other person's next piece comes on their turn.
- In each set of 3, the point stays the same. Only the wording changes:
  * One statement, ending in a period
  * One question, ending in a question mark
  * One exclamation or reaction, ending in an exclamation mark
- Finish every line. Do not stop halfway.
- On a User B turn, if a hint exists, that shared point is the hint, spoken as "You said I ...".

✅ CORRECT STRUCTURE:
- Turn 1: User A says "I am upset about the office issue."
- Turn 2 (User B), the same feeling three ways:
  * "I've been upset about that too." (straight)
  * "I've been upset about it too." (shorter)
  * "Have you been as upset about it as I have?" (same feeling, small question)
- Turn 3 (User A), the same feeling three ways:
  * "I felt left out of that conversation." (straight)
  * "I felt left out." (shorter)
  * "Did I seem left out to you?" (same feeling, small question)

❌ WRONG EXAMPLES (avoid these):
- "Thanks for understanding. Can we fix this and move on?" (wraps the talk up, and more than one piece) ❌
- A line that stops halfway or ends with "..." ❌
- Three options that are all statements ❌
- "How are you?" (ignores what they just said) ❌

Keep them supportive, natural, and consistent with the conversation.
If near closure, add a smiley-only option as one of the 3.
Choose appropriate emoji from: 🙂 😊 😌 ❤️ 💕 🤝 ✨
Match to relationship type and conversation tone:
- Family: ❤️ 💕 😊 😌 (warm, supportive)
- Friends: 😊 😌 🤝 ✨ (happy, friendly, playful)
- Work: 🤝 🙂 ✨ (professional, respectful)
- Romantic: ❤️ 💕 😊 😌 (intimate, caring, affectionate)

${finalClosureState?.startsWith('pending_') ? `
🚨🚨🚨 CRITICAL CLOSURE REMINDER - READ THIS FIRST 🚨🚨🚨

⚠️ CLOSURE PENDING - ONE USER ALREADY SENT A SMILEY:
- ${finalClosureState === 'pending_user_a_smiley' ? 'User A' : 'User B'} has ALREADY sent a single smiley emoji
- The conversation is waiting for ${finalClosureState === 'pending_user_a_smiley' ? 'User A' : 'User B'} to respond with a smiley
- This is the CORE FEATURE of the app - smooth closure resolution

⚡ MANDATORY REQUIREMENT FOR ${finalClosureState === 'pending_user_a_smiley' ? 'USER A' : 'USER B'} TURNS:
- EVERY set of 3 options for ${finalClosureState === 'pending_user_a_smiley' ? 'User A' : 'User B'} MUST include exactly ONE single smiley-only option
- This applies to ALL batches generated while closure is pending
- The smiley option should be one of: 🙂 😊 😌 ❤️ 💕 🤝 ✨
- Choose emoji based on relationship type:
  * Family: ❤️ 💕 😊 😌 (warm, supportive)
  * Friends: 😊 😌 🤝 ✨ (happy, friendly, playful)
  * Work: 🤝 🙂 ✨ (professional, respectful)
  * Romantic: ❤️ 💕 😊 😌 (intimate, caring, affectionate)
- The other 2 options should be text-based (appreciation, understanding, moving forward)
- User can choose text options if they want, but smiley option MUST be available

🎯 REMINDER: This is a REMINDER that closure is pending. Even if the conversation continues with text messages, ${finalClosureState === 'pending_user_a_smiley' ? 'User A' : 'User B'} MUST always have a smiley option available until they send one.

⚠️ DO NOT FORGET: If you generate options for ${finalClosureState === 'pending_user_a_smiley' ? 'User A' : 'User B'} and forget to include a single smiley option, the conversation will drag on unnecessarily. This is the core feature - always include it.
` : ''}

⚠️ CONVERSATION EVOLUTION - DO NOT RESTART:
- The problem/issue has already been discussed in previous messages
- Options should EVOLVE emotionally: acknowledgment → reflection → acceptance → closure
- DO NOT re-explain the problem, re-analyze the situation, or restart the discussion
- Focus on: understanding, validation, moving forward, closure signals, peace
- If the conversation shows closure signals (thanks, understanding, peace, smileys), reflect that progression
- Avoid options that loop back to problem analysis, justification, or re-explaining what happened
${finalClosureState?.startsWith('pending_') ? '- Once closure is pending, options should focus on: appreciation, mutual understanding, peace, moving forward' : ''}
${bothSidesShared || hasClosureSignals ? `
🚫🚫🚫 CRITICAL: BOTH SIDES HAVE SHARED THEIR PERSPECTIVES OR CLOSURE SIGNALS DETECTED 🚫🚫🚫
${bothSidesShared ? '- User A has explained their issue/feelings' : ''}
${bothSidesShared ? '- User B has explained their perspective/feelings' : ''}
${hasClosureSignals ? '- Closure signals detected in recent messages (appreciation, understanding, moving forward)' : ''}
- Both sides have been heard and understood OR conversation is showing closure readiness

⚡ STOP CONTINUING THE PROBLEM DISCUSSION:
- DO NOT generate options that re-explain the problem
- DO NOT generate options that ask for more details about what happened
- DO NOT generate options that analyze or justify the situation further
- DO NOT generate options that restart the discussion

✅ INSTEAD, generate options that:
- Show appreciation: "Thanks for sharing your side", "I appreciate you explaining"
- Express understanding: "I understand where you're coming from", "That makes sense"
- Move toward closure: "I'm glad we talked about this", "Thanks for hearing me out"
- ⚠️ MANDATORY: Include exactly ONE smiley-only option as one of the 3 options (choose appropriate emoji: 🙂 😊 😌 ❤️ 💕 🤝 ✨)
- The smiley option must be ONLY the emoji, NO text before or after it
- The other 2 options should be text-based (appreciation, understanding, moving forward)

🚨 CRITICAL: If you generate 3 options and NONE of them is a single smiley-only option, you have FAILED. The conversation will drag on unnecessarily. ALWAYS include one single smiley option when closure is detected.

The conversation has reached mutual understanding or closure readiness - guide it toward peaceful closure, NOT continued discussion.
` : ''}
- DO NOT restart the problem discussion even if users continue with text messages

CONVERSATION CONTEXT:
${conversationHistory.length > 0 ? `
${conversationProgressSummary ? `📋 Conversation Progress (background context - neutral summary):
${conversationProgressSummary}

Use this to maintain continuity with earlier parts of the conversation that aren't in the recent messages below.
⚠️ CRITICAL: This summary is in neutral third-person with "User A"/"User B" labels. When generating turns, NEVER use these labels - always use first/second person pronouns:
- Turn 1 (${firstTurnRole === "A" ? "User A" : "User B"}): Use "I/me/my" for ${firstTurnRole === "A" ? "User A" : "User B"}, "you/your" for ${firstTurnRole === "A" ? "User B" : "User A"} - NEVER say "User A", "User B", or use the other person's actual name when addressing them directly
- Turn 2 (${firstTurnRole === "A" ? "User B" : "User A"}): Use "I/me/my" for ${firstTurnRole === "A" ? "User B" : "User A"}, "you/your" for ${firstTurnRole === "A" ? "User A" : "User B"} - NEVER say "User A", "User B", or use the other person's actual name when addressing them directly
- Turn 3 (${firstTurnRole === "A" ? "User A" : "User B"}): Use "I/me/my" for ${firstTurnRole === "A" ? "User A" : "User B"}, "you/your" for ${firstTurnRole === "A" ? "User B" : "User A"} - NEVER say "User A", "User B", or use the other person's actual name when addressing them directly
- Third parties (people not in the conversation) use their names or pronouns (he/she/they)
- ⚠️ MANDATORY: When addressing the other person directly, ALWAYS use "you/your" - NEVER use their actual name. Example: "When you suggested" NOT "When [Name] suggested". Using their name makes it sound like you're talking about them in third person, which is wrong.

` : ''}Recent messages (last ${conversationHistory.length} message(s)):
${conversationHistory.map((msg: any, idx: number) => 
  `${idx + 1}. ${msg.sender_id === userAId ? 'User A' : 'User B'}: "${msg.content}"`
).join('\n')}

Use this history to understand the conversation flow and ensure your generated turns:
- Turn 1 (if starting): Begin naturally
- Turn 2: MUST respond to Turn 1 AND add new content
- Turn 3: MUST respond to Turn 2 AND add new content
` : 'This is the start of the conversation.'}
`}`;

    // ✅ IMPROVED: Robust JSON extraction function with better error handling
    function extractJSON(text: string): string | null {
      if (!text || typeof text !== 'string') {
        console.error("❌ extractJSON: Invalid input - text is not a string");
        return null;
      }
      
      // Try markdown code block first (```json ... ```)
      const block = text.match(/```json\s*([\s\S]*?)```/);
      if (block) {
        const extracted = block[1].trim();
        if (extracted.startsWith('{') && (extracted.includes('"turns"') || extracted.includes("'turns'"))) {
          console.log("✅ Found JSON in markdown code block (json)");
          return extracted;
        }
      }
      
      // Try markdown code block without language tag (``` ... ```)
      const blockNoLang = text.match(/```\s*([\s\S]*?)```/);
      if (blockNoLang) {
        const content = blockNoLang[1].trim();
        // Check if it looks like JSON with "turns" key
        if (content.startsWith('{') && (content.includes('"turns"') || content.includes("'turns'"))) {
          console.log("✅ Found JSON in markdown code block (no lang)");
          return content;
        }
      }
      
      // Try to find JSON object that contains "turns" key
      const jsonMatch = text.match(/\{\s*"turns"\s*:[\s\S]*\}/);
      if (jsonMatch) {
        console.log("✅ Found JSON with 'turns' key");
        return jsonMatch[0];
      }
      
      // Last resort: find any JSON object and validate it has "turns"
      const loose = text.match(/\{[\s\S]*\}/);
      if (loose) {
        const candidate = loose[0];
        // Validate it has "turns" key
        if (candidate.includes('"turns"') || candidate.includes("'turns'")) {
          console.log("✅ Found JSON object with 'turns' (loose match)");
          return candidate;
        }
      }
      
      console.error("❌ extractJSON: No valid JSON found in response");
      console.error("❌ Response preview:", text.substring(0, 500));
      return null;
    }

    // ✅ FIX: Call Anthropic API with retry logic to ensure we get exactly 3 turns
    console.log('🤖 Calling Anthropic API for 3-turn generation...');
    
    let turnsData: any = null;
    let responseText = '';
    const maxRetries = 2;
    let attempt = 0;
    
    while (attempt <= maxRetries && (!turnsData || !turnsData.turns || turnsData.turns.length !== 3)) {
      if (attempt > 0) {
        console.warn(`⚠️ Retry attempt ${attempt}/${maxRetries} - previous response had ${turnsData?.turns?.length || 0} turns (expected 3)`);
        // Wait a bit before retry
        await new Promise(resolve => setTimeout(resolve, 1000));
      }
      
      const anthropicResponse = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-api-key": CLAUDE_API_KEY,
          "anthropic-version": "2023-06-01"
        },
        body: JSON.stringify({
          model: "claude-haiku-4-5-20251001",
          max_tokens: 3000, // ✅ Increased from 2000 to ensure enough space for all 3 turns
          temperature: 0.7,
          system: systemPrompt,
          messages: [
            {
              role: "user",
              content: userPrompt
            }
          ]
        })
      });

      if (!anthropicResponse.ok) {
        const errorText = await anthropicResponse.text();
        console.error("❌ Anthropic API error:", errorText);
        if (attempt === maxRetries) {
          return new Response(JSON.stringify({
            error: 'Anthropic API failed',
            details: errorText
          }), {
            status: 500,
            headers: {
              ...corsHeaders,
              'Content-Type': 'application/json'
            }
          });
        }
        attempt++;
        continue;
      }

      const anthropicData = await anthropicResponse.json();
      responseText = anthropicData.content[0].text;

      console.log("🟦 Raw response:", responseText);

      // Extract and parse JSON response
      const jsonString = extractJSON(responseText);
      if (!jsonString) {
        if (attempt === maxRetries) {
          throw new Error("No JSON found in AI response after retries");
        }
        attempt++;
        continue;
      }

      try {
        turnsData = JSON.parse(jsonString);
        console.log("🟧 Parsed json:", JSON.stringify(turnsData, null, 2));
      } catch (parseError) {
        console.error("❌ JSON parse error:", parseError);
        console.error("❌ JSON string that failed:", jsonString.substring(0, 500));
        if (attempt === maxRetries) {
          throw new Error("Failed to parse extracted JSON: " + (parseError instanceof Error ? parseError.message : String(parseError)));
        }
        attempt++;
        continue;
      }

      // ✅ Check if we got exactly 3 turns - if not, retry
      if (turnsData.turns && Array.isArray(turnsData.turns) && turnsData.turns.length === 3) {
        // ✅ CRITICAL FIX: Validate roles match expected sequence BEFORE accepting response
        // Use firstTurnRole to determine expected sequence (matches AI prompt logic)
        // NOT turn number parity - the sequence is determined by firstTurnRole
        let hasRoleMismatch = false;
        for (let i = 0; i < 3; i++) {
          const turn = turnsData.turns[i];
          if (!turn || !turn.role) {
            hasRoleMismatch = true;
            console.error(`❌ Turn ${i} missing role field`);
            break;
          }
          
          // ✅ FIX: Use firstTurnRole to determine expected role (matches AI prompt logic)
          // The sequence is: firstTurnRole → opposite → firstTurnRole
          let expectedRole: string;
          if (i === 0) {
            // First turn in batch = firstTurnRole
            expectedRole = firstTurnRole === "A" ? "User A" : "User B";
          } else if (i === 1) {
            // Second turn in batch = opposite of firstTurnRole
            expectedRole = firstTurnRole === "A" ? "User B" : "User A";
          } else {
            // Third turn in batch = firstTurnRole again
            expectedRole = firstTurnRole === "A" ? "User A" : "User B";
          }
          
          const turnNumber = startingTurnNumber + i;
          const aiRole = turn.role === "A" ? "User A" : (turn.role === "B" ? "User B" : turn.role);
          
          if (aiRole !== expectedRole) {
            hasRoleMismatch = true;
            console.error(`❌ CRITICAL: Role mismatch at turn ${turnNumber} (index ${i}): AI said "${aiRole}" but expected "${expectedRole}"`);
            console.error(`❌ This means options were generated for wrong user - REJECTING response and retrying`);
            break;
          }
        }
        
        if (!hasRoleMismatch) {
          console.log(`✅ Successfully received exactly 3 turns with correct roles on attempt ${attempt + 1}`);
          break; // Success! Exit retry loop
        } else {
          // Role mismatch detected - retry
          if (attempt === maxRetries) {
            console.error(`❌ Role mismatch persisted after ${maxRetries + 1} attempts - this is a critical error`);
            // Return error response instead of continuing with wrong roles
            return new Response(JSON.stringify({
              error: 'Role mismatch in AI response',
              details: 'AI generated turns with incorrect roles after multiple retries. Options would be shown to wrong users.',
              startingTurnNumber,
              maxRetries: maxRetries + 1
            }), {
              status: 500,
              headers: { ...corsHeaders, 'Content-Type': 'application/json' }
            });
          } else {
            console.warn(`⚠️ Role mismatch detected - retrying generation (attempt ${attempt + 1}/${maxRetries + 1})...`);
            attempt++;
            turnsData = null; // Reset to force retry
            continue;
          }
        }
      } else {
        const turnsReceived = turnsData.turns?.length || 0;
        console.warn(`⚠️ Received ${turnsReceived} turns (expected 3) - will retry if attempts remaining`);
        if (attempt === maxRetries) {
          // Last attempt failed - log warning but continue with what we have
          console.warn(`⚠️ Final attempt failed - got ${turnsReceived} turns instead of 3. Processing available turns.`);
          break;
        }
        attempt++;
      }
    }

    // ✅ FIX: Validate response structure - accept 1-3 turns (not just exactly 3)
    // After retries, process whatever we got to avoid user-facing errors
    if (!turnsData || !turnsData.turns || !Array.isArray(turnsData.turns) || turnsData.turns.length === 0) {
      console.error("❌ Invalid response structure: No turns array or empty array:", turnsData);
      return new Response(JSON.stringify({
        error: 'Invalid AI response structure',
        details: 'No turns found in response after retries'
      }), {
        status: 500,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }

    const turnsReceived = turnsData.turns.length;
    // ✅ CRITICAL: Validate we got exactly 3 turns (except in hint refresh mode)
    // Hint refresh mode can generate 1 turn, but normal batches must be exactly 3
    if (!hintRefreshMode && turnsReceived !== 3) {
      console.error(`❌ CRITICAL: Expected exactly 3 turns, got ${turnsReceived}`);
      return new Response(JSON.stringify({
        error: `Expected exactly 3 turns, got ${turnsReceived}`,
        success: false,
        turnsReceived
      }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }
    
    // ✅ FIX: Accept 1-3 turns in hint refresh mode, log warning if partial
    if (hintRefreshMode && turnsReceived < 1) {
      console.warn(`⚠️ Partial response in hint refresh mode: Expected at least 1 turn, got ${turnsReceived}`);
    } else if (!hintRefreshMode && turnsReceived < 3) {
      console.warn(`⚠️ Partial response after ${maxRetries + 1} attempts: Expected 3 turns, got ${turnsReceived}. Processing available turns.`);
    }

    // ✅ Helper function to check if text is emoji-only
    const isEmojiOnly = (text: string): boolean => {
      // Check if text is exactly one emoji (no other characters except whitespace)
      const trimmed = text.trim();
      // Unicode emoji regex pattern
      const emojiPattern = /^[\p{Emoji}\u{1F300}-\u{1F9FF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}]+$/u;
      return emojiPattern.test(trimmed) && trimmed.length > 0;
    };

    // ✅ ENHANCED: Helper function to determine if smiley should be enforced for a turn
    const shouldEnforceSmiley = (turnIndex: number, recipientId: string): boolean => {
      // Check if this turn should have a smiley option
      // ✅ IMPORTANT: pending_user_a_smiley means we're waiting for User A to send a smiley (so enforce for User A),
      // and pending_user_b_smiley means we're waiting for User B (so enforce for User B).
      const isTargetUser = finalClosureState?.startsWith('pending_')
        ? (finalClosureState === 'pending_user_a_smiley' && recipientId === userAId) ||
          (finalClosureState === 'pending_user_b_smiley' && recipientId === userBId)
        : (userASmileySent && recipientId === userBId) ||
          (userBSmileySent && recipientId === userAId);
      
      // ✅ ENHANCED: Also enforce if both sides have shared AND mutual understanding detected
      const bothSidesSharedAndUnderstood = bothSidesShared && hasMutualUnderstanding;
      
      // ✅ NEW: Also enforce if closure signals detected (even without full bothSidesShared)
      const closureSignalsDetected = hasClosureSignals && conversationHistory.length >= 4;
      
      // Also enforce if closure is detected (not active/early)
      const closureDetected = finalClosureState && 
        finalClosureState !== 'active' && 
        finalClosureState !== 'early' && 
        !finalClosureState.startsWith('pending_');
      
      // ✅ CRITICAL: Enforce smiley if ANY of these conditions are true
      const shouldEnforce = isTargetUser || closureDetected || bothSidesSharedAndUnderstood || closureSignalsDetected;
      
      if (shouldEnforce) {
        console.log(`😊 SMILEY ENFORCEMENT: Turn ${turnIndex} for ${recipientId === userAId ? 'User A' : 'User B'} - REASON:`, {
          isTargetUser,
          closureDetected,
          bothSidesSharedAndUnderstood,
          closureSignalsDetected,
          finalClosureState,
          conversationLength: conversationHistory.length
        });
      }
      
      return shouldEnforce;
    };

    // ✅ FIX: Insert rows into pregenerated_turns table with correct global turn_number
    // Only insert turns that don't already exist (to avoid gaps and preserve used turns)
    // ✅ CRITICAL: In normal mode, must insert exactly 3 turns
    // ✅ GUARDRAIL: In hint refresh mode, only insert the active turn (i=0)
    const maxTurnsToInsert = hintRefreshMode ? 1 : 3; // Always 3 in normal mode, 1 in hint refresh
    const inserts = [];
    for (let i = 0; i < maxTurnsToInsert && i < turnsReceived; i++) {
      const turn = turnsData.turns[i];
      
      if (!turn || !turn.role || !turn.options || !Array.isArray(turn.options) || turn.options.length === 0) {
        console.error(`❌ Invalid turn ${i}:`, turn);
        continue;
      }

      // ✅ FIX: Accept any number of options (not just exactly 3) - log warning if partial
      if (turn.options.length < 3) {
        console.warn(`⚠️ Turn ${i} has ${turn.options.length} options (expected 3). Processing available options.`);
      }

      // ✅ FIX 2: Calculate role and recipient_id based on firstTurnRole sequence, NOT turn_number parity
      // The sequence is determined by firstTurnRole: firstTurnRole → opposite → firstTurnRole
      // This matches the AI prompt logic and validation logic above
      const turnNumber = startingTurnNumber + i;
      let role: string;
      let recipientId: string;
      
      if (i === 0) {
        // First turn in batch = firstTurnRole
        role = firstTurnRole === "A" ? "User A" : "User B";
        recipientId = firstTurnRole === "A" ? userAId : userBId;
      } else if (i === 1) {
        // Second turn in batch = opposite of firstTurnRole
        role = firstTurnRole === "A" ? "User B" : "User A";
        recipientId = firstTurnRole === "A" ? userBId : userAId;
      } else {
        // Third turn in batch = firstTurnRole again
        role = firstTurnRole === "A" ? "User A" : "User B";
        recipientId = firstTurnRole === "A" ? userAId : userBId;
      }
      
      // ✅ VALIDATION: Role should already be validated in retry loop, but double-check here
      const aiRole = turn.role === "A" ? "User A" : (turn.role === "B" ? "User B" : turn.role);
      if (aiRole !== role) {
        // This should never happen if retry logic worked, but log error if it does
        console.error(`❌ CRITICAL: Role mismatch at turn ${turnNumber} passed retry validation - this should not happen!`);
        console.error(`❌ AI said "${aiRole}" but calculated "${role}" - using calculated role but options may be wrong`);
      }
      
      // ✅ FIX 4: Check if this turn already exists (with or without selected_message)
      // This prevents duplicate turn numbers, especially when batchStartTurn is provided and frontend preserved turns with selected_message
      const existingTurn = existingTurns?.find((t: { turn_number: number }) => t.turn_number === turnNumber);
      if (existingTurn) {
        // Turn already exists - skip insertion to preserve it (especially if it has selected_message)
        console.log(`⏸️ Turn ${turnNumber} already exists - skipping insertion to preserve existing turn`, {
          hasSelectedMessage: !!existingTurn.selected_message,
          recipientId: existingTurn.recipient_id,
          turnNumber: existingTurn.turn_number
        });
        continue;
      }

      // Prepare context_data snapshot
      const turnContextData = {
        finalClosureDetected: turn.finalClosureDetected || false,
        generatedAt: new Date().toISOString(),
        turnIndex: i,
        batchStart: startingTurnNumber,
        partialResponse: turnsReceived < 3 // Track if this was from a partial response
      };

      // ✅ Helper functions for pronoun fixing (ported from generate-contextual-options)
      const escapeRegex = (value: string): string =>
        value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

      const buildNameVariants = (name: string | null | undefined): string[] => {
        if (!name || typeof name !== 'string') return [];
        const normalized = name.trim().replace(/\s+/g, ' ');
        if (!normalized) return [];

        const baseParts = normalized
          .split(/[\s-]+/)
          .map(part => part.trim())
          .filter(Boolean);

        const variants = new Set<string>();
        variants.add(normalized);
        baseParts.forEach(part => variants.add(part));

        return Array.from(variants);
      };

      const applySentenceCase = (replacement: string, offset: number, source: string): string => {
        const prefix = source.slice(0, offset);
        const isStartOfSentence =
          offset === 0 ||
          /[.!?]\s*$/.test(prefix) ||
          prefix.trimEnd().length === 0;

        if (!isStartOfSentence) {
          return replacement.toLowerCase() === 'i' ? 'I' : replacement;
        }

        if (replacement.toLowerCase() === 'you') return 'You';
        if (replacement.toLowerCase() === 'your') return 'Your';
        if (replacement.toLowerCase() === 'i') return 'I';
        if (replacement.toLowerCase() === 'me') return 'Me';
        if (replacement.toLowerCase() === 'my') return 'My';

        return replacement;
      };

      const applySentenceCaseToPhrase = (replacement: string, offset: number, source: string): string => {
        const parts = replacement.split(' ');
        if (parts.length === 0) return replacement;
        const [first, ...rest] = parts;
        const firstWord = applySentenceCase(first, offset, source);
        return [firstWord, ...rest].join(' ');
      };

      // ✅ Get contact name from context_data or fetch from contacts table
      let contactName: string | null = null;
      try {
        // Try to get from context_data first
        if (contextData?.contact_name || contextData?.contactName) {
          contactName = contextData.contact_name || contextData.contactName;
        } else {
          // Fetch from contacts table
          const { data: contactData } = await supabase
            .from("contacts")
            .select("contact_profile:profiles!contacts_contact_id_fkey(full_name)")
            .eq("user_id", userAId)
            .eq("contact_id", userBId)
            .maybeSingle();
          
          if (contactData) {
            const profile = Array.isArray(contactData.contact_profile) 
              ? contactData.contact_profile[0] 
              : contactData.contact_profile;
            contactName = profile?.full_name || null;
          }
        }
      } catch (err) {
        console.warn("⚠️ Could not fetch contact name for pronoun fixing:", err);
      }

      // ✅ NEW: Comprehensive pronoun fixing (ported from generate-contextual-options)
      const fixPronounMistakes = (option: string, recipientId: string, userAId: string, userBId: string, contactName?: string | null): string => {
        if (!option || typeof option !== 'string') return option;
        let fixed = option;
        
        const isRecipientUserA = recipientId === userAId;
        const isRecipientUserB = recipientId === userBId;
        const userAName = isRecipientUserA ? null : (contactName || null);
        const userBName = isRecipientUserB ? null : (contactName || null);
        
        // ✅ STEP 1: Remove listener name references (same as generate-contextual-options)
        const removeListenerName = (text: string): string => {
          if (!text || typeof text !== 'string') return text;
          let cleaned = text;
          const listenerName = isRecipientUserA ? userBName : userAName;
          const listenerVariants = buildNameVariants(listenerName);

          if (listenerVariants.length === 0) return cleaned;

          listenerVariants.forEach(variant => {
            const escaped = escapeRegex(variant);
            const hasSpace = /\s/.test(variant);

            // Replace plain name references
            cleaned = cleaned.replace(new RegExp(`\\b${escaped}'s\\b`, 'gi'), (match, offset, source) =>
              applySentenceCase('your', offset, source)
            );
            cleaned = cleaned.replace(new RegExp(`\\b${escaped}'\\b`, 'gi'), (match, offset, source) =>
              applySentenceCase('your', offset, source)
            );
            cleaned = cleaned.replace(new RegExp(`\\b${escaped}\\b`, 'gi'), (match, offset, source) =>
              applySentenceCase('you', offset, source)
            );

            // Handle @ patterns
            if (hasSpace) {
              cleaned = cleaned.replace(new RegExp(`@\\s*${escaped}'s\\b`, 'gi'), (match, offset, source) =>
                applySentenceCase('your', offset, source)
              );
              cleaned = cleaned.replace(new RegExp(`@\\s*${escaped}'\\b`, 'gi'), (match, offset, source) =>
                applySentenceCase('your', offset, source)
              );
              cleaned = cleaned.replace(new RegExp(`@\\s*${escaped}\\b`, 'gi'), (match, offset, source) =>
                applySentenceCase('you', offset, source)
              );
            } else {
              cleaned = cleaned.replace(new RegExp(`@\\s*${escaped}'s\\b`, 'gi'), (match, offset, source) =>
                applySentenceCase('your', offset, source)
              );
              cleaned = cleaned.replace(new RegExp(`@\\s*${escaped}'\\b`, 'gi'), (match, offset, source) =>
                applySentenceCase('your', offset, source)
              );
              cleaned = cleaned.replace(new RegExp(`@\\s*${escaped}\\b`, 'gi'), (match, offset, source) =>
                applySentenceCase('you', offset, source)
              );
            }
          });

          return cleaned;
        };
        
        // ✅ STEP 2: Apply listener phrase fixes
        const applyListenerPhraseFixes = (input: string): string => {
          let output = input;

          const possessiveTargets = [
            'perspective', 'side', 'point of view', 'point-of-view', 'point', 'feelings', 'thoughts',
            'take', 'story', 'stories', 'reasons', 'experience', 'experiences', 'situation', 'situations',
            'needs', 'opinion', 'opinions', 'feedback', 'actions', 'behavior', 'choices', 'life', 'world',
            'friendship', 'relationship', 'comments', 'comment', 'words', 'energy', 'time', 'effort'
          ];

          possessiveTargets.forEach(target => {
            const pattern = new RegExp(`\\btheir ${escapeRegex(target)}\\b`, 'gi');
            output = output.replace(pattern, (match, offset, source) =>
              applySentenceCaseToPhrase(`your ${target}`, offset, source)
            );
          });

          output = output.replace(/\btheirs\b/gi, (match, offset, source) =>
            applySentenceCaseToPhrase('yours', offset, source)
          );

          const simpleThemPhrases: Array<{ pattern: RegExp; replacement: string }> = [
            { pattern: /\bunderstand them\b/gi, replacement: 'understand you' },
            { pattern: /\bhear them\b/gi, replacement: 'hear you' },
            { pattern: /\bhear them out\b/gi, replacement: 'hear you out' },
            { pattern: /\bsupport them\b/gi, replacement: 'support you' },
            { pattern: /\bhelp them\b/gi, replacement: 'help you' },
            { pattern: /\breach out to them\b/gi, replacement: 'reach out to you' },
            { pattern: /\bcheck on them\b/gi, replacement: 'check on you' },
            { pattern: /\bcheck in on them\b/gi, replacement: 'check in on you' },
            { pattern: /\bbe there for them\b/gi, replacement: 'be there for you' },
            { pattern: /\bfor their sake\b/gi, replacement: 'for your sake' }
          ];

          simpleThemPhrases.forEach(({ pattern, replacement }) => {
            output = output.replace(pattern, (match, offset, source) =>
              applySentenceCaseToPhrase(replacement, offset, source)
            );
          });

          output = output.replace(/\btalk (to|with) them\b/gi, (match, preposition, offset, source) =>
            applySentenceCaseToPhrase(`talk ${preposition.toLowerCase()} you`, offset, source)
          );

          output = output.replace(/\bspeak (to|with) them\b/gi, (match, preposition, offset, source) =>
            applySentenceCaseToPhrase(`speak ${preposition.toLowerCase()} you`, offset, source)
          );

          output = output.replace(/\bchat (to|with) them\b/gi, (match, preposition, offset, source) =>
            applySentenceCaseToPhrase(`chat ${preposition.toLowerCase()} you`, offset, source)
          );

          output = output.replace(/\blisten to them\b/gi, (match, offset, source) =>
            applySentenceCaseToPhrase('listen to you', offset, source)
          );

          return output;
        };
        
        // ✅ STEP 3: Comprehensive possessive noun replacement (with context checking)
        const possessiveNouns = [
          'stuff', 'things', 'comment', 'comments', 'behavior', 'actions', 'words', 'tone', 'attitude',
          'approach', 'support', 'help', 'effort', 'job', 'promotion', 'success', 'wins', 'achievements',
          'accomplishments', 'relationship', 'friendship', 'situation', 'perspective', 'view', 'plan',
          'plans', 'idea', 'ideas', 'response', 'reaction', 'side', 'feelings', 'thoughts', 'needs',
          'opinion', 'opinions', 'feedback', 'choices', 'life', 'world', 'experience', 'experiences'
        ];
        
        if (isRecipientUserA || isRecipientUserB) {
          possessiveNouns.forEach(noun => {
            // Pattern: "her noun", "his noun", "their noun" → "your noun" (with context check)
            fixed = fixed.replace(new RegExp(`\\b(her|his|their)\\s+${noun}\\b`, 'gi'), (match, pronoun, offset, source) => {
              const contextStart = Math.max(0, offset - 30);
              const contextEnd = Math.min(source.length, offset + match.length + 30);
              const context = source.substring(contextStart, contextEnd).toLowerCase();
              
              const hasThirdPartyReference = /\b(to|about|with|from|talking to|speaking to|congratulating|talking about|speaking about)\s+(her|him|them|she|he|they)\b/i.test(context);
              const beforeMatch = source.substring(contextStart, offset);
              const hasThirdPartyName = /\b[A-Z][a-z]+(?:\s+[A-Z][a-z]+)?\s+(her|his|their)\s+${noun}\b/i.test(beforeMatch + match);
              
              if (!hasThirdPartyReference && !hasThirdPartyName) {
                return applySentenceCaseToPhrase(`your ${noun}`, offset, source);
              }
              return match;
            });
            
            // Pattern: "her own noun", "his own noun", "their own noun" → "your own noun"
            fixed = fixed.replace(new RegExp(`\\b(her|his|their)\\s+own\\s+${noun}\\b`, 'gi'), (match, pronoun, offset, source) => {
              const contextStart = Math.max(0, offset - 30);
              const contextEnd = Math.min(source.length, offset + match.length + 30);
              const context = source.substring(contextStart, contextEnd).toLowerCase();
              
              const hasThirdPartyReference = /\b(to|about|with|from|talking to|speaking to|congratulating|talking about|speaking about)\s+(her|him|them|she|he|they)\b/i.test(context);
              const beforeMatch = source.substring(contextStart, offset);
              const hasThirdPartyName = /\b[A-Z][a-z]+(?:\s+[A-Z][a-z]+)?\s+(her|his|their)\\s+own\\s+${noun}\b/i.test(beforeMatch + match);
              
              if (!hasThirdPartyReference && !hasThirdPartyName) {
                return applySentenceCaseToPhrase(`your own ${noun}`, offset, source);
              }
              return match;
            });
          });
          
          // Common phrases
          const commonPhrases = [
            { pattern: /\bjealous of (her|his|their)\b/gi, replacement: 'jealous of your' },
            { pattern: /\bof (her|his|their) stuff\b/gi, replacement: 'of your stuff' },
            { pattern: /\bof (her|his|their) things\b/gi, replacement: 'of your things' },
            { pattern: /\b(her|his|their) comment\b/gi, replacement: 'your comment' },
            { pattern: /\b(her|his|their) behavior\b/gi, replacement: 'your behavior' },
            { pattern: /\b(her|his|their) actions\b/gi, replacement: 'your actions' },
            { pattern: /\b(her|his|their) words\b/gi, replacement: 'your words' },
            { pattern: /\b(her|his|their) side\b/gi, replacement: 'your side' },
            { pattern: /\b(her|his|their) perspective\b/gi, replacement: 'your perspective' },
            { pattern: /\b(her|his|their) feelings\b/gi, replacement: 'your feelings' },
            { pattern: /\b(her|his|their) thoughts\b/gi, replacement: 'your thoughts' },
          ];
          
          commonPhrases.forEach(({ pattern, replacement }) => {
            fixed = fixed.replace(pattern, (match, offset, source) => {
              const contextStart = Math.max(0, offset - 30);
              const contextEnd = Math.min(source.length, offset + match.length + 30);
              const context = source.substring(contextStart, contextEnd).toLowerCase();
              
              const hasThirdPartyReference = /\b(to|about|with|from|talking to|speaking to|congratulating|talking about|speaking about)\s+(her|him|them|she|he|they)\b/i.test(context);
              
              if (!hasThirdPartyReference) {
                return applySentenceCaseToPhrase(replacement, offset, source);
              }
              return match;
            });
          });
          
          fixed = applyListenerPhraseFixes(fixed);
        }
        
        // ✅ STEP 4: Remove listener name (after pronoun fixes)
        fixed = removeListenerName(fixed);
        
        // Capitalize first letter
        if (fixed.length > 0) {
          fixed = fixed.charAt(0).toUpperCase() + fixed.slice(1);
        }
        
        return fixed;
      };

      // The other person's set is rewritten in their voice before the existing pronoun and smiley steps.
      if (recipientId === userBId) {
        const rewritten = await rewriteOtherPersonsLines(
          CLAUDE_API_KEY,
          turn.options.map((opt: string) => String(opt)),
          [thoughtsA, contextData.summary_a || ""].filter(Boolean).join("\n"),
          "",
          hintFromB || ""
        );
        if (rewritten) turn.options = rewritten;
      }

      // ✅ POST-GENERATION ENFORCEMENT: Ensure exactly one emoji-only option when needed
      let finalOptions = [...turn.options]; // Copy options array
      
      // ✅ NEW: Fix pronouns in all options before smiley enforcement
      finalOptions = finalOptions.map(opt => 
        fixPronounMistakes(opt, recipientId, userAId, userBId, contactName)
      );
      
      if (shouldEnforceSmiley(i, recipientId)) {
        const emojiCount = finalOptions.filter(opt => isEmojiOnly(opt)).length;
        
        if (emojiCount === 0) {
          // No emoji-only option found - add one
          const emojiPool = ['🙂', '😊', '😌', '❤️', '💕', '🤝', '✨'];
          // Choose emoji based on relationship type (you may need to extract this from context_data)
          const chosenEmoji = emojiPool[Math.floor(Math.random() * emojiPool.length)];
          // Replace the last option with emoji-only
          finalOptions[finalOptions.length - 1] = chosenEmoji;
          console.log(`✅ POST-GEN: Enforced smiley option for turn ${turnNumber} (replaced last option)`);
        } else if (emojiCount > 1) {
          // Too many emoji-only options - keep first, convert others to text
          let emojiFound = false;
          finalOptions = finalOptions.map(opt => {
            if (isEmojiOnly(opt)) {
              if (!emojiFound) {
                emojiFound = true;
                return opt; // Keep first emoji
              } else {
                // Convert additional emojis to text (add context-appropriate text)
                const textVariants = [
                  "Thanks! 😊",
                  "Appreciate it! 🙂",
                  "Got it! ✨"
                ];
                return textVariants[Math.floor(Math.random() * textVariants.length)];
              }
            }
            return opt;
          });
          console.log(`✅ POST-GEN: Reduced smiley count for turn ${turnNumber} (kept 1 emoji-only)`);
        }
        // If emojiCount === 1, we're good - no changes needed
      }

      inserts.push({
        chat_id: chatId,
        turn_number: turnNumber, // ✅ Use global turn_number, not loop index - ensures sequential storage
        recipient_id: recipientId,
        role: role,
        options: finalOptions,
        selected_message: null,
        used_at: null,
        source: null, // ✅ Set to NULL initially - will be set when user selects an option
        context_data: turnContextData
      });
    }

    // ✅ FIX 4: Allow fewer than 3 inserts if some turns already exist (prevents gaps)
    if (inserts.length === 0) {
      console.log('ℹ️ All turns already exist - no insertion needed');
      return new Response(JSON.stringify({
        success: true,
        stored: 0,
        message: 'All turns already exist - preserved existing turns',
        startingTurnNumber,
        existingTurnNumbers
      }), {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }
    
    if (inserts.length < 3) {
      console.log(`ℹ️ Only ${inserts.length} turns need to be inserted (${3 - inserts.length} already exist)`);
    }

    console.log("🟩 Inserts:", JSON.stringify(inserts, null, 2));

    // ✅ CRITICAL FIX: Only delete turns if we're actually going to regenerate (not if idempotency check passed)
    // This prevents deletion of turns that are currently being viewed
    // Note: The deletion above (lines 256-287) only happens if there are gaps or partial turns
    // This deletion should only happen if we didn't return early from idempotency check
    
    
    
    
    // ✅ NOTE: We keep used turns in pregenerated_turns until chat closes
    // When chat closes, archive-pregenerated-turns function will archive them
    // This ensures full audit trail while keeping active table clean
    // No need to delete old used turns here - they'll be archived on closure

    // ✅ FIX 4: Insert only missing turns (ensures sequential storage without gaps)
    // ✅ CRITICAL: In normal mode, validate we're inserting exactly 3 turns (or fewer if some exist)
    if (!hintRefreshMode && inserts.length > 3) {
      console.error(`❌ CRITICAL: Attempting to insert ${inserts.length} turns, but maximum is 3`);
      return new Response(JSON.stringify({
        error: `Cannot insert more than 3 turns per batch`,
        success: false
      }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }
    
    console.log(`💾 Inserting ${inserts.length} pre-generated turn(s) (ensuring sequential storage)...`);
    const { data: insertedData, error: insertError } = await supabase
      .from("pregenerated_turns")
      .insert(inserts)
      .select();

    if (insertError) {
      // ✅ FIX: Handle unique constraint violation gracefully
      if (insertError.code === '23505') {
        // Unique constraint violation - turns already exist
        console.log('ℹ️ Unique constraint violation - turns may already exist, checking...');
        
        // Check if the turns actually exist
        const { data: existingCheck } = await supabase
          .from('pregenerated_turns')
          .select('turn_number')
          .eq('chat_id', chatId)
          .gte('turn_number', startingTurnNumber)
          .lte('turn_number', startingTurnNumber + 2);
        
        if (existingCheck && existingCheck.length >= 3) {
          // Turns already exist - return success (idempotent)
          console.log('✅ Turns already exist - returning success (idempotent)');
          return new Response(JSON.stringify({
            success: true,
            stored: existingCheck.length,
            message: 'Pregenerated turns already exist',
            startingTurnNumber,
            turnNumbers: existingCheck.map((t: any) => t.turn_number)
          }), {
            status: 200,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
          });
        }
      }
      
      console.error("❌ Failed to insert pre-generated turns:", insertError);
      console.error("❌ Insert error details:", JSON.stringify(insertError, null, 2));
      console.error("❌ Attempted inserts:", JSON.stringify(inserts, null, 2));
      return new Response(JSON.stringify({
        error: 'Failed to store pre-generated turns',
        details: insertError.message,
        code: insertError.code,
        hint: insertError.hint
      }), {
        status: 500,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }

    if (!insertedData || insertedData.length === 0) {
      console.error("❌ Insert succeeded but no rows returned:", insertedData?.length || 0);
      return new Response(JSON.stringify({
        error: 'Failed to store pre-generated turns',
        details: `Expected at least 1 row, got ${insertedData?.length || 0}`
      }), {
        status: 500,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      });
    }

    // 🔧 FIX: Validate each expected turn WITH correct recipient_id
    const insertedTurnNumbers = insertedData.map((t: any) => t.turn_number);
    const [t0, t1, t2] = [
      { tn: startingTurnNumber,     rid: firstRecipientId },
      { tn: startingTurnNumber + 1, rid: secondRecipientId },
      { tn: startingTurnNumber + 2, rid: thirdRecipientId }
    ];

    const finalCheckResults = [];

    for (const t of [t0, t1, t2]) {
      const { data: row } = await supabase
        .from('pregenerated_turns')
        .select('turn_number')
        .eq('chat_id', chatId)
        .eq('turn_number', t.tn)
        .eq('recipient_id', t.rid)
        .maybeSingle();

      if (row) finalCheckResults.push(row.turn_number);
    }

    const finalTurnNumbers = finalCheckResults;
    const hasAllTurns = finalTurnNumbers.length === 3;
    
    if (!hasAllTurns) {
      const missing = [t0.tn, t1.tn, t2.tn].filter(tn => !finalTurnNumbers.includes(tn));
      console.warn(`⚠️ Gap detected in turn sequence - missing turn numbers: ${missing.join(', ')}`);
    } else {
      console.log(`✅ All turns stored sequentially: ${finalTurnNumbers.sort((a, b) => a - b).join(', ')}`);
    }

    console.log(`✅ Successfully stored ${insertedData.length} pre-generated turn(s) starting from turn_number ${startingTurnNumber}`);
    console.log('✅ Inserted turn IDs:', insertedData.map((t: any) => ({ id: t.id, turn_number: t.turn_number, recipient_id: t.recipient_id })));

    return new Response(JSON.stringify({
      success: true,
      stored: insertedData.length,
      deferred: false, // Only true when pendingHint && !latestMessageFromA (handled in early return above)
      startingTurnNumber: startingTurnNumber,
      turnNumbers: finalTurnNumbers.sort((a, b) => a - b), // Return all turns in sequence
      insertedTurnNumbers: insertedTurnNumbers
    }), {
      status: 200,
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json'
      }
    });

  } catch (error) {
    console.error('❌ Error in generate-pregenerated-turns:', error);
    return new Response(JSON.stringify({
      error: 'Internal server error',
      details: error instanceof Error ? error.message : 'Unknown error'
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json'
      }
    });
  }
});

